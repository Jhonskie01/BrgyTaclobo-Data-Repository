
  # Barangay Data Repository UI

  This is a code bundle for Barangay Data Repository UI. The original project is available at https://www.figma.com/design/rP6O5L6wSzWIqx6Xl8oe1I/Barangay-Data-Repository-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  