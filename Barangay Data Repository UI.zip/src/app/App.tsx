import React, { useState } from "react";
import { Toaster, toast } from "sonner";

import { LoginView } from "./components/LoginView";
import { Sidebar } from "./components/Sidebar";
import { StaffSidebar } from "./components/StaffSidebar";
import { TopNavbar } from "./components/TopNavbar";

import { DashboardView } from "./components/DashboardView";
import { StaffDashboardView } from "./components/StaffDashboardView";
import { StaffProfileView } from "./components/StaffProfileView";

import { ResidentsView } from "./components/ResidentsView";
import { HouseholdsView } from "./components/HouseholdsView";
import { DocumentsView } from "./components/DocumentsView";
import { CertificatesView } from "./components/CertificatesView";
import { IncidentsView } from "./components/IncidentsView";
import { ProjectsView } from "./components/ProjectsView";
import { ReportsView } from "./components/ReportsView";
import { DataManagementView } from "./components/DataManagementView";
import { NotificationsView } from "./components/NotificationsView";
import { UserManagementView } from "./components/UserManagementView";
import { BackupView } from "./components/BackupView";
import { SettingsView } from "./components/SettingsView";

type AdminView =
  | "dashboard"
  | "residents"
  | "households"
  | "documents"
  | "certificates"
  | "incidents"
  | "projects"
  | "reports"
  | "data"
  | "notifications"
  | "users"
  | "backup"
  | "settings";

type StaffView =
  | "staff-dashboard"
  | "residents"
  | "households"
  | "documents"
  | "certificates"
  | "incidents"
  | "projects"
  | "reports"
  | "notifications"
  | "staff-profile";

type UserRole = "admin" | "staff" | null;

interface User {
  name: string;
  role: "admin" | "staff";
}

const adminViewComponents: Record<
  AdminView,
  React.ComponentType
> = {
  dashboard: DashboardView,
  residents: ResidentsView,
  households: HouseholdsView,
  documents: DocumentsView,
  certificates: CertificatesView,
  incidents: IncidentsView,
  projects: ProjectsView,
  reports: ReportsView,
  data: DataManagementView,
  notifications: NotificationsView,
  users: UserManagementView,
  backup: BackupView,
  settings: SettingsView,
};

const staffViewComponents: Record<
  StaffView,
  React.ComponentType
> = {
  "staff-dashboard": StaffDashboardView,
  residents: ResidentsView,
  households: HouseholdsView,
  documents: DocumentsView,
  certificates: CertificatesView,
  incidents: IncidentsView,
  projects: ProjectsView,
  reports: ReportsView,
  notifications: NotificationsView,
  "staff-profile": StaffProfileView,
};

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>(null);

  // ✅ NEW: user object (FIX FOR TOPNAVBAR)
  const [user, setUser] = useState<User | null>(null);

  const [currentView, setCurrentView] =
    useState<string>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // LOGIN
  const handleLogin = (role: "admin" | "staff") => {
    setUserRole(role);
    setIsAuthenticated(true);

    // ✅ CREATE USER OBJECT FOR TOPNAVBAR
    const mockUser =
      role === "admin"
        ? { name: "Administrator", role: "admin" as const }
        : { name: "Staff User", role: "staff" as const };

    setUser(mockUser);

    setCurrentView(
      role === "admin" ? "dashboard" : "staff-dashboard",
    );

    toast.success(
      `Welcome ${role === "admin" ? "Admin" : "Staff"}!`,
    );
  };

  // LOGOUT
  const handleLogout = () => {
    toast.success("Logged out successfully");

    setIsAuthenticated(false);
    setUserRole(null);
    setUser(null); // ✅ IMPORTANT FIX
    setCurrentView("dashboard");
  };

  // NAVIGATION
  const navigate = (view: string) => {
    if (userRole === "staff") {
      const restrictedViews = [
        "users",
        "backup",
        "settings",
        "data",
      ];

      if (restrictedViews.includes(view)) {
        toast.error("Access denied: Admin only feature");
        return;
      }
    }

    setCurrentView(view);
  };

  // LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <>
        <Toaster position="top-right" />
        <LoginView onLogin={handleLogin} />
      </>
    );
  }

  // CURRENT VIEW
  const CurrentView =
    userRole === "admin"
      ? adminViewComponents[currentView as AdminView] ||
        DashboardView
      : staffViewComponents[currentView as StaffView] ||
        StaffDashboardView;

  return (
    <div
      className={`flex h-screen overflow-hidden ${darkMode ? "dark" : ""}`}
      style={{ background: "#f1f5f9" }}
    >
      {/* TOAST */}
      <Toaster position="top-right" />

      {/* SIDEBAR */}
      {userRole === "admin" ? (
        <Sidebar
          currentView={currentView}
          onNavigate={navigate}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onLogout={handleLogout}
        />
      ) : (
        <StaffSidebar
          currentView={currentView}
          onNavigate={navigate}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onLogout={handleLogout}
        />
      )}

      {/* MAIN AREA */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* NAVBAR (✅ FIXED USER PASSED HERE) */}
        <TopNavbar
          onMenuToggle={() => setSidebarOpen((prev) => !prev)}
          darkMode={darkMode}
          onDarkModeToggle={() => setDarkMode((prev) => !prev)}
          onNavigate={navigate}
          user={user ?? { name: "User", role: "staff" }} // fallback safety
        />

        {/* CONTENT */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <CurrentView />
        </main>
      </div>
    </div>
  );
}