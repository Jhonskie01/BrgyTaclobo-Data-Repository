import React, { useState, useEffect } from "react";
import {
  Search,
  Bell,
  ChevronDown,
  Moon,
  Sun,
  Menu,
  User,
  LogOut,
  Settings,
} from "lucide-react";
import { Switch } from "./ui/switch";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

/**
 * Notification mock (replace with Supabase later)
 */
const notifications = [
  {
    id: 1,
    text: "New resident registration submitted",
    time: "2 min ago",
    unread: true,
  },
  {
    id: 2,
    text: "Certificate request received",
    time: "15 min ago",
    unread: true,
  },
  {
    id: 3,
    text: "Blotter report updated",
    time: "1 hr ago",
    unread: false,
  },
];

interface UserProps {
  name: string;
  role: "admin" | "staff";
}

interface TopNavbarProps {
  onMenuToggle: () => void;
  darkMode: boolean;
  onDarkModeToggle: () => void;
  onNavigate: (view: string) => void;
  user: UserProps;
}

export function TopNavbar({
  onMenuToggle,
  darkMode,
  onDarkModeToggle,
  onNavigate,
  user,
}: TopNavbarProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const fmtTime = (d: Date) =>
    d.toLocaleTimeString("en-PH", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

  const fmtDate = (d: Date) =>
    d.toLocaleDateString("en-PH", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  const unreadCount = notifications.filter((n) => n.unread).length;

  // Generate initials dynamically
  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  // Role label
  const roleLabel =
    user.role === "admin" ? "Administrator" : "Staff";

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center px-4 gap-3 sticky top-0 z-30 shadow-sm">

      {/* Mobile Menu */}
      <button
        onClick={onMenuToggle}
        className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Search */}
      <div className="flex-1 max-w-lg relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search residents, documents..."
          className="w-full pl-9 pr-4 py-2 bg-slate-50 border rounded-xl text-sm focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="flex items-center gap-2 ml-auto">

        {/* Date & Time */}
        <div className="hidden xl:flex flex-col items-end">
          <span className="text-sm font-semibold text-blue-700">
            {fmtTime(currentTime)}
          </span>
          <span className="text-xs text-slate-500">
            {fmtDate(currentTime)}
          </span>
        </div>

        {/* Dark Mode */}
        <div className="hidden sm:flex items-center gap-2 px-2 py-1 bg-slate-50 rounded-lg border">
          <Sun className="w-4 h-4 text-amber-500" />
          <Switch
            checked={darkMode}
            onCheckedChange={onDarkModeToggle}
            className="scale-75"
          />
          <Moon className="w-4 h-4 text-slate-500" />
        </div>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="relative p-2 hover:bg-slate-100 rounded-xl">
              <Bell className="w-5 h-5 text-slate-600" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
          </DropdownMenuTrigger>

          <DropdownMenuContent className="w-80" align="end">
            <div className="p-3 border-b font-semibold">
              Notifications
            </div>

            {notifications.map((n) => (
              <div
                key={n.id}
                className="p-3 hover:bg-slate-50 border-b"
              >
                <p className="text-sm">{n.text}</p>
                <p className="text-xs text-slate-400">{n.time}</p>
              </div>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* PROFILE (ROLE BASED FIX) */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 px-2 py-1 rounded-xl hover:bg-slate-100">

              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold
                ${user.role === "admin"
                    ? "bg-gradient-to-br from-blue-500 to-blue-700"
                    : "bg-gradient-to-br from-green-500 to-green-700"
                  }`}
              >
                {initials}
              </div>

              {/* Name + Role */}
              <div className="hidden md:block text-left">
                <p className="text-sm font-semibold text-slate-800">
                  {user.name}
                </p>
                <p className="text-xs text-slate-500">
                  {roleLabel}
                </p>
              </div>

              <ChevronDown className="w-4 h-4 text-slate-400 hidden md:block" />
            </button>
          </DropdownMenuTrigger>

          <DropdownMenuContent align="end" className="w-48">

            <DropdownMenuItem className="gap-2 cursor-pointer">
              <User className="w-4 h-4" /> Profile
            </DropdownMenuItem>

            <DropdownMenuItem
              className="gap-2 cursor-pointer"
              onClick={() => onNavigate("settings")}
            >
              <Settings className="w-4 h-4" /> Settings
            </DropdownMenuItem>

            <DropdownMenuSeparator />

            <DropdownMenuItem className="gap-2 cursor-pointer text-red-600">
              <LogOut className="w-4 h-4" /> Logout
            </DropdownMenuItem>

          </DropdownMenuContent>
        </DropdownMenu>

      </div>
    </header>
  );
}