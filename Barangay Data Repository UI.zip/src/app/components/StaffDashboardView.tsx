import React, { useState } from 'react';
import { Users, Home, FileText, Award, AlertTriangle, Briefcase, TrendingUp, TrendingDown, Clock, CheckCircle, AlertCircle, Calendar, BarChart3 } from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Cell, ResponsiveContainer } from 'recharts';

export function StaffDashboardView() {
  const [currentDateTime] = useState(new Date());

  // Analytics Data
  const analyticsCards = [
    { title: 'Total Residents', value: '2,847', trend: '+12', icon: Users, color: 'bg-blue-500', trendUp: true },
    { title: 'Total Households', value: '842', trend: '+5', icon: Home, color: 'bg-green-500', trendUp: true },
    { title: 'Certificates Today', value: '23', trend: '+8', icon: Award, color: 'bg-purple-500', trendUp: true },
    { title: 'Pending Requests', value: '15', trend: '-3', icon: Clock, color: 'bg-orange-500', trendUp: false },
    { title: 'Uploaded Documents', value: '156', trend: '+24', icon: FileText, color: 'bg-indigo-500', trendUp: true },
    { title: 'Open Incidents', value: '8', trend: '-2', icon: AlertTriangle, color: 'bg-red-500', trendUp: false },
    { title: 'Active Projects', value: '12', trend: '+1', icon: Briefcase, color: 'bg-teal-500', trendUp: true },
    { title: 'Recent Activities', value: '47', trend: '+11', icon: CheckCircle, color: 'bg-cyan-500', trendUp: true },
  ];

  // Chart Data
  const residentsByPurok = [
    { name: 'Purok 1', residents: 245 },
    { name: 'Purok 2', residents: 312 },
    { name: 'Purok 3', residents: 289 },
    { name: 'Purok 4', residents: 356 },
    { name: 'Purok 5', residents: 298 },
    { name: 'Purok 6', residents: 267 },
    { name: 'Purok 7', residents: 324 },
    { name: 'Purok 8', residents: 256 },
  ];

  const certificateRequests = [
    { month: 'Jan', requests: 65 },
    { month: 'Feb', requests: 78 },
    { month: 'Mar', requests: 92 },
    { month: 'Apr', requests: 105 },
    { month: 'May', requests: 118 },
  ];

  const incidentStatus = [
    { name: 'Pending', value: 8, color: '#F59E0B' },
    { name: 'Investigating', value: 12, color: '#3B82F6' },
    { name: 'Resolved', value: 45, color: '#10B981' },
    { name: 'Closed', value: 23, color: '#6B7280' },
  ];

  const projectProgress = [
    { name: 'Planned', value: 3, color: '#9CA3AF' },
    { name: 'Ongoing', value: 8, color: '#3B82F6' },
    { name: 'Completed', value: 15, color: '#10B981' },
    { name: 'Suspended', value: 2, color: '#EF4444' },
  ];

  // Recent Tasks
  const recentTasks = [
    { id: 1, title: 'Certificate of Indigency Request', priority: 'High', status: 'Pending', dueDate: '2026-05-31', type: 'Certificate' },
    { id: 2, title: 'New Resident Registration - Maria Santos', priority: 'Medium', status: 'In Progress', dueDate: '2026-06-01', type: 'Resident' },
    { id: 3, title: 'Document Upload - Barangay ID Copy', priority: 'Low', status: 'Pending', dueDate: '2026-06-02', type: 'Document' },
    { id: 4, title: 'Incident Report - Noise Complaint', priority: 'High', status: 'Investigating', dueDate: '2026-05-30', type: 'Incident' },
    { id: 5, title: 'Business Permit Endorsement', priority: 'Medium', status: 'Pending', dueDate: '2026-06-03', type: 'Certificate' },
  ];

  const formatDateTime = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-red-100 text-red-700 border-red-200';
      case 'Medium': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Low': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-orange-100 text-orange-700';
      case 'In Progress': return 'bg-blue-100 text-blue-700';
      case 'Investigating': return 'bg-purple-100 text-purple-700';
      case 'Completed': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back, Staff</h1>
            <div className="space-y-1">
              <p className="text-lg font-semibold text-[#1E40AF]">Juan Dela Cruz</p>
              <p className="text-sm text-gray-600">Barangay Staff</p>
              <div className="flex items-center gap-4 mt-2">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  <span>{formatDateTime(currentDateTime)}</span>
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                  STAFF ACCESS
                </div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600 mb-1">Assigned Barangay</p>
            <p className="text-lg font-semibold text-gray-900">Barangay San Miguel</p>
            <p className="text-xs text-gray-500 mt-1">Last Login: Today, 8:45 AM</p>
          </div>
        </div>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {analyticsCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300 cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`flex items-center gap-1 text-sm font-medium ${card.trendUp ? 'text-green-600' : 'text-red-600'}`}>
                  {card.trendUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  <span>{card.trend}</span>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{card.value}</h3>
              <p className="text-sm text-gray-600">{card.title}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Residents per Purok */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Residents per Purok</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={residentsByPurok}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="residents" fill="#3B82F6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Certificate Requests per Month */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Certificate Requests per Month</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={certificateRequests}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="requests" stroke="#8B5CF6" strokeWidth={3} dot={{ fill: '#8B5CF6', r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Incident Status Analytics */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Incident Status Analytics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={incidentStatus}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {incidentStatus.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Project Progress Overview */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Project Progress Overview</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={projectProgress}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}`}
              >
                {projectProgress.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Tasks and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Tasks Panel */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Tasks & Pending Items</h3>
          <div className="space-y-3">
            {recentTasks.map((task) => (
              <div
                key={task.id}
                className="p-4 bg-gray-50 rounded-xl border border-gray-200 hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-2">{task.title}</h4>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`px-2 py-1 rounded-md text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                        {task.priority} Priority
                      </span>
                      <span className={`px-2 py-1 rounded-md text-xs font-medium ${getStatusColor(task.status)}`}>
                        {task.status}
                      </span>
                      <span className="text-xs text-gray-500">{task.type}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500 mb-1">Due Date</p>
                    <p className="text-sm font-medium text-gray-900">{task.dueDate}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full p-4 bg-gradient-to-r from-[#1E40AF] to-[#3B82F6] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <Users className="w-5 h-5" />
              Add Resident
            </button>
            <button className="w-full p-4 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <Home className="w-5 h-5" />
              Register Household
            </button>
            <button className="w-full p-4 bg-gradient-to-r from-purple-600 to-purple-500 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <Award className="w-5 h-5" />
              Issue Certificate
            </button>
            <button className="w-full p-4 bg-gradient-to-r from-indigo-600 to-indigo-500 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <FileText className="w-5 h-5" />
              Upload Document
            </button>
            <button className="w-full p-4 bg-gradient-to-r from-red-600 to-red-500 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Incident Report
            </button>
            <button className="w-full p-4 bg-gradient-to-r from-teal-600 to-teal-500 text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Generate Report
            </button>
          </div>
        </div>
      </div>

      {/* Staff Permissions Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Staff Access Permissions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-green-700 mb-2">✓ Allowed Actions:</p>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Manage Residents</li>
                  <li>• Manage Households</li>
                  <li>• Manage Documents</li>
                  <li>• Process Certificates</li>
                  <li>• Manage Incidents</li>
                  <li>• Generate Reports</li>
                </ul>
              </div>
              <div>
                <p className="text-sm font-medium text-red-700 mb-2">✗ Restricted Actions:</p>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• User Management</li>
                  <li>• System Settings</li>
                  <li>• Database Backup</li>
                  <li>• Restore Operations</li>
                  <li>• Permission Controls</li>
                  <li>• Delete Residents (Requires Admin Approval)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
