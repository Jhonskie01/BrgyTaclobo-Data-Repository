import React, { useState } from 'react';
import { Plus, Search, Eye, AlertTriangle, Clock, CheckCircle, XCircle, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';

type Priority = 'Low' | 'Medium' | 'High' | 'Critical';
type IncStatus = 'Pending' | 'Under Investigation' | 'Resolved' | 'Closed';

const initialIncidents = [
  { id: 1, blotterNo: 'BLT-2026-091', title: 'Domestic Disturbance', complainant: 'Maria Santos', respondent: 'Juan Santos', purok: 'Purok 4', priority: 'High' as Priority, status: 'Pending' as IncStatus, date: 'May 28, 2026', description: 'Reported domestic dispute at Blk 1 Lot 3. Respondent allegedly created disturbance at night.' },
  { id: 2, blotterNo: 'BLT-2026-090', title: 'Theft of Personal Property', complainant: 'Pedro Bautista', respondent: 'Unknown', purok: 'Purok 7', priority: 'Medium' as Priority, status: 'Under Investigation' as IncStatus, date: 'May 27, 2026', description: 'Complainant reports theft of mobile phone and cash from residence.' },
  { id: 3, blotterNo: 'BLT-2026-089', title: 'Noise Complaint', complainant: 'Ana Gonzales', respondent: 'Carlos Garcia', purok: 'Purok 1', priority: 'Low' as Priority, status: 'Resolved' as IncStatus, date: 'May 26, 2026', description: 'Excessive noise from neighboring unit after 10PM.' },
  { id: 4, blotterNo: 'BLT-2026-088', title: 'Physical Assault', complainant: 'Rosa Flores', respondent: 'Roberto Reyes', purok: 'Purok 8', priority: 'Critical' as Priority, status: 'Under Investigation' as IncStatus, date: 'May 25, 2026', description: 'Complainant reports being physically assaulted. Medical certificate attached.' },
  { id: 5, blotterNo: 'BLT-2026-087', title: 'Trespassing', complainant: 'Elena Ramos', respondent: 'Unknown', purok: 'Purok 2', priority: 'Medium' as Priority, status: 'Closed' as IncStatus, date: 'May 24, 2026', description: 'Unknown individuals found on private property.' },
  { id: 6, blotterNo: 'BLT-2026-086', title: 'Illegal Parking', complainant: 'Jose Torres', respondent: 'Neighborhood Resident', purok: 'Purok 4', priority: 'Low' as Priority, status: 'Resolved' as IncStatus, date: 'May 23, 2026', description: 'Vehicle blocking entrance to property.' },
  { id: 7, blotterNo: 'BLT-2026-085', title: 'Drug Suspicion Report', complainant: 'Barangay Watch', respondent: 'Unknown', purok: 'Purok 6', priority: 'Critical' as Priority, status: 'Pending' as IncStatus, date: 'May 22, 2026', description: 'Suspicious activity reported by barangay watch. Referred to proper authorities.' },
];

type Incident = typeof initialIncidents[0];

const PriorityBadge = ({ priority }: { priority: Priority }) => {
  const styles: Record<Priority, string> = {
    Low: 'bg-slate-100 text-slate-600 border border-slate-200',
    Medium: 'bg-amber-50 text-amber-700 border border-amber-200',
    High: 'bg-orange-50 text-orange-700 border border-orange-200',
    Critical: 'bg-red-50 text-red-700 border border-red-200',
  };
  const dots: Record<Priority, string> = { Low: 'bg-slate-400', Medium: 'bg-amber-500', High: 'bg-orange-500', Critical: 'bg-red-600' };
  return (
    <span className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full w-fit ${styles[priority]}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[priority]}`} />
      {priority}
    </span>
  );
};

const StatusBadge = ({ status }: { status: IncStatus }) => {
  const styles: Record<IncStatus, string> = {
    'Pending': 'bg-amber-50 text-amber-700 border border-amber-200',
    'Under Investigation': 'bg-blue-50 text-blue-700 border border-blue-200',
    'Resolved': 'bg-emerald-50 text-emerald-700 border border-emerald-200',
    'Closed': 'bg-slate-100 text-slate-600 border border-slate-200',
  };
  const icons: Record<IncStatus, React.ElementType> = {
    'Pending': Clock,
    'Under Investigation': AlertTriangle,
    'Resolved': CheckCircle,
    'Closed': XCircle,
  };
  const Icon = icons[status];
  return (
    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full w-fit ${styles[status]}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>
      <Icon className="w-3 h-3" />
      {status}
    </span>
  );
};

const emptyForm = { title: '', complainant: '', respondent: '', purok: 'Purok 1', priority: 'Low' as Priority, description: '' };

const summaryCards = [
  { label: 'Total Incidents', value: 7, color: '#1d4ed8', bg: '#eff6ff', icon: AlertTriangle },
  { label: 'Pending', value: 2, color: '#d97706', bg: '#fffbeb', icon: Clock },
  { label: 'Under Investigation', value: 2, color: '#7c3aed', bg: '#f5f3ff', icon: AlertTriangle },
  { label: 'Resolved', value: 3, color: '#059669', bg: '#ecfdf5', icon: CheckCircle },
];

export function IncidentsView() {
  const [incidents, setIncidents] = useState(initialIncidents);
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [selected, setSelected] = useState<Incident | null>(null);
  const [form, setForm] = useState(emptyForm);
  const PER_PAGE = 6;

  const filtered = incidents.filter(i => {
    const q = search.toLowerCase();
    const match = !search || i.title.toLowerCase().includes(q) || i.blotterNo.toLowerCase().includes(q) || i.complainant.toLowerCase().includes(q);
    return match && (priorityFilter === 'All' || i.priority === priorityFilter) && (statusFilter === 'All' || i.status === statusFilter);
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleAdd = () => {
    const newI = {
      ...form, id: incidents.length + 1,
      blotterNo: `BLT-2026-${String(92 + incidents.length - 7).padStart(3, '0')}`,
      status: 'Pending' as IncStatus,
      date: 'May 29, 2026',
      respondent: form.respondent || 'Unknown'
    };
    setIncidents([newI, ...incidents]);
    setShowAdd(false);
    setForm(emptyForm);
    toast.success('Incident report filed');
  };

  const updateStatus = (id: number, status: IncStatus) => {
    setIncidents(incidents.map(i => i.id === id ? { ...i, status } : i));
    toast.success(`Status updated to ${status}`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Incident / Blotter</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>{filtered.length} incidents found</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <Plus className="w-4 h-4" /> File Incident
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map((c, i) => {
          const Icon = c.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: c.bg }}>
                  <Icon className="w-4 h-4" style={{ color: c.color }} />
                </div>
                <p style={{ fontSize: '26px', fontWeight: 700, color: c.color }}>{c.value}</p>
              </div>
              <p style={{ fontSize: '12.5px', color: '#64748b' }}>{c.label}</p>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search by title, blotter number, complainant..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            {[['Priority', priorityFilter, setPriorityFilter, ['All', 'Low', 'Medium', 'High', 'Critical']],
              ['Status', statusFilter, setStatusFilter, ['All', 'Pending', 'Under Investigation', 'Resolved', 'Closed']]
            ].map(([label, val, setter, opts]) => (
              <select key={label as string} value={val as string}
                onChange={e => { (setter as any)(e.target.value); setPage(1); }}
                className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {(opts as string[]).map(o => <option key={o}>{o === 'All' ? `${label}: All` : o}</option>)}
              </select>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['Blotter No.', 'Incident Title', 'Complainant', 'Purok', 'Priority', 'Status', 'Date', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.map(inc => (
                <tr key={inc.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <span style={{ fontSize: '12.5px', fontWeight: 700, color: '#1d4ed8', fontFamily: 'monospace' }}>{inc.blotterNo}</span>
                  </td>
                  <td className="px-4 py-3">
                    <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{inc.title}</p>
                    <p style={{ fontSize: '11.5px', color: '#94a3b8' }}>vs. {inc.respondent}</p>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{inc.complainant}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{inc.purok}</td>
                  <td className="px-4 py-3"><PriorityBadge priority={inc.priority} /></td>
                  <td className="px-4 py-3"><StatusBadge status={inc.status} /></td>
                  <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b' }}>{inc.date}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setSelected(inc); setShowDetail(true); }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      {inc.status === 'Pending' && (
                        <button onClick={() => updateStatus(inc.id, 'Under Investigation')}
                          className="px-2 py-1 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                          style={{ fontSize: '11px', fontWeight: 500 }}>
                          Investigate
                        </button>
                      )}
                      {inc.status === 'Under Investigation' && (
                        <button onClick={() => updateStatus(inc.id, 'Resolved')}
                          className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                          style={{ fontSize: '11px', fontWeight: 500 }}>
                          Resolve
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
          <p style={{ fontSize: '12.5px', color: '#94a3b8' }}>
            Showing {Math.min((page - 1) * PER_PAGE + 1, filtered.length)}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}
          </p>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => (
              <button key={i + 1} onClick={() => setPage(i + 1)}
                className={`w-8 h-8 rounded-lg text-sm ${page === i + 1 ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-600'}`}>{i + 1}</button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add Modal */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>File Incident Report</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Incident Title</label>
              <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })}
                placeholder="Brief description of incident"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Complainant</label>
                <input value={form.complainant} onChange={e => setForm({ ...form, complainant: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Respondent</label>
                <input value={form.respondent} onChange={e => setForm({ ...form, respondent: e.target.value })}
                  placeholder="Unknown if not identified"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[['Purok', 'purok', ['Purok 1', 'Purok 2', 'Purok 3', 'Purok 4', 'Purok 5', 'Purok 6', 'Purok 7', 'Purok 8']],
                ['Priority', 'priority', ['Low', 'Medium', 'High', 'Critical']]].map(([label, key, opts]) => (
                <div key={key as string}>
                  <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                  <select value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Description</label>
              <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                rows={3} placeholder="Detailed description of the incident..."
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAdd}>File Report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Modal */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Incident Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl" style={{ background: 'linear-gradient(135deg, #fef2f2, #fff7ed)' }}>
                <div className="flex items-center justify-between mb-2">
                  <span style={{ fontFamily: 'monospace', fontWeight: 700, color: '#1d4ed8', fontSize: '13px' }}>{selected.blotterNo}</span>
                  <PriorityBadge priority={selected.priority} />
                </div>
                <p style={{ fontWeight: 700, color: '#1e293b', fontSize: '16px' }}>{selected.title}</p>
                <StatusBadge status={selected.status} />
              </div>
              <div className="space-y-2">
                {[['Complainant', selected.complainant], ['Respondent', selected.respondent], ['Purok', selected.purok], ['Date Filed', selected.date], ['Description', selected.description]].map(([k, v]) => (
                  <div key={k as string} className={`py-2 border-b border-slate-50 ${k === 'Description' ? 'flex flex-col gap-1' : 'flex justify-between'}`}>
                    <span style={{ fontSize: '12.5px', color: '#64748b', fontWeight: 600 }}>{k}</span>
                    <span style={{ fontSize: '13px', color: '#1e293b' }}>{v}</span>
                  </div>
                ))}
              </div>
              {/* Timeline */}
              <div>
                <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b', marginBottom: '8px' }}>Timeline</p>
                <div className="space-y-2">
                  {[
                    { event: 'Incident reported', date: selected.date, color: '#1d4ed8' },
                    ...(selected.status !== 'Pending' ? [{ event: 'Investigation started', date: 'May 29, 2026', color: '#7c3aed' }] : []),
                    ...(selected.status === 'Resolved' || selected.status === 'Closed' ? [{ event: 'Case resolved', date: 'May 29, 2026', color: '#10b981' }] : []),
                  ].map((t, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: t.color }} />
                      <span style={{ fontSize: '12.5px', color: '#1e293b' }}>{t.event}</span>
                      <span style={{ fontSize: '11px', color: '#94a3b8', marginLeft: 'auto' }}>{t.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setShowDetail(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
