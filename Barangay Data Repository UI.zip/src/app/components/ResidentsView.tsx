import React, { useState } from "react";
import {
  Plus,
  Search,
  Filter,
  Edit,
  Trash2,
  Eye,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "./ui/dialog";
import { toast } from "sonner";

const puroks = [
  "All",
  "Purok 1",
  "Purok 2",
  "Purok 3",
  "Purok 4",
  "Purok 5",
  "Purok 6",
  "Purok 7",
  "Purok 8",
];
const genders = ["All", "Male", "Female"];
const ageGroups = [
  "All",
  "0-12 - Kids",
  "13-19 - Teenager",
  "20-59 - Adult",
  "60+ - Senior",
];
const statuses = ["All", "Active", "Inactive", "Deceased"];

const initialResidents = [
  {
    id: 1,
    firstName: "Juan",
    middleName: "Cruz",
    lastName: "Dela Cruz",
    age: 34,
    gender: "Male",
    contact: "09171234567",
    purok: "Purok 4",
    occupation: "Farmer",
    status: "Active",
    civilStatus: "Married",
    voter: true,
    email: "juan@email.com",
    notes: "",
  },
  {
    id: 2,
    firstName: "Maria",
    middleName: "L.",
    lastName: "Clara Santos",
    age: 28,
    gender: "Female",
    contact: "09281234567",
    purok: "Purok 2",
    occupation: "Teacher",
    status: "Active",
    civilStatus: "Single",
    voter: true,
    email: "maria@email.com",
    notes: "",
  },
  {
    id: 3,
    firstName: "Roberto",
    middleName: "P.",
    lastName: "Reyes",
    age: 52,
    gender: "Male",
    contact: "09391234567",
    purok: "Purok 6",
    occupation: "Driver",
    status: "Active",
    civilStatus: "Married",
    voter: true,
    email: "",
    notes: "",
  },
  {
    id: 4,
    firstName: "Ana",
    middleName: "M.",
    lastName: "Gonzales",
    age: 19,
    gender: "Female",
    contact: "09471234567",
    purok: "Purok 1",
    occupation: "Student",
    status: "Active",
    civilStatus: "Single",
    voter: false,
    email: "ana@email.com",
    notes: "",
  },
  {
    id: 5,
    firstName: "Pedro",
    middleName: "R.",
    lastName: "Bautista",
    age: 41,
    gender: "Male",
    contact: "09551234567",
    purok: "Purok 7",
    occupation: "Carpenter",
    status: "Active",
    civilStatus: "Married",
    voter: true,
    email: "",
    notes: "",
  },
  {
    id: 6,
    firstName: "Liza",
    middleName: "A.",
    lastName: "Mendoza",
    age: 65,
    gender: "Female",
    contact: "09661234567",
    purok: "Purok 3",
    occupation: "Retired",
    status: "Active",
    civilStatus: "Widowed",
    voter: true,
    email: "",
    notes: "Senior Citizen",
  },
  {
    id: 7,
    firstName: "Carlos",
    middleName: "B.",
    lastName: "Garcia",
    age: 23,
    gender: "Male",
    contact: "09771234567",
    purok: "Purok 5",
    occupation: "College Student",
    status: "Active",
    civilStatus: "Single",
    voter: false,
    email: "carlos@email.com",
    notes: "",
  },
  {
    id: 8,
    firstName: "Rosa",
    middleName: "C.",
    lastName: "Flores",
    age: 48,
    gender: "Female",
    contact: "09881234567",
    purok: "Purok 8",
    occupation: "Vendor",
    status: "Active",
    civilStatus: "Married",
    voter: true,
    email: "",
    notes: "4Ps beneficiary",
  },
  {
    id: 9,
    firstName: "Jose",
    middleName: "D.",
    lastName: "Torres",
    age: 72,
    gender: "Male",
    contact: "09991234567",
    purok: "Purok 4",
    occupation: "Retired",
    status: "Inactive",
    civilStatus: "Widowed",
    voter: false,
    email: "",
    notes: "PWD",
  },
  {
    id: 10,
    firstName: "Elena",
    middleName: "E.",
    lastName: "Ramos",
    age: 35,
    gender: "Female",
    contact: "09121234567",
    purok: "Purok 2",
    occupation: "Nurse",
    status: "Active",
    civilStatus: "Married",
    voter: true,
    email: "elena@email.com",
    notes: "",
  },
];

type Resident = (typeof initialResidents)[0];

const emptyForm = {
  firstName: "",
  middleName: "",
  lastName: "",
  age: "",
  gender: "Male",
  contact: "",
  email: "",
  occupation: "",
  civilStatus: "Single",
  purok: "Purok 1",
  voter: false,
  status: "Active",
  notes: "",
  birthDate: "",
};

const StatusBadge = ({ status }: { status: string }) => {
  const colors: Record<string, string> = {
    Active:
      "bg-emerald-50 text-emerald-700 border border-emerald-200",
    Inactive:
      "bg-slate-100 text-slate-600 border border-slate-200",
    Deceased: "bg-red-50 text-red-700 border border-red-200",
  };
  return (
    <span
      className={`px-2 py-0.5 rounded-full ${colors[status] || "bg-slate-100 text-slate-600"}`}
      style={{ fontSize: "11.5px", fontWeight: 500 }}
    >
      {status}
    </span>
  );
};

export function ResidentsView() {
  const [residents, setResidents] = useState(initialResidents);
  const [search, setSearch] = useState("");
  const [purokFilter, setPurokFilter] = useState("All");
  const [genderFilter, setGenderFilter] = useState("All");
  const [ageGroupFilter, setAgeGroupFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [page, setPage] = useState(1);
  const [showAdd, setShowAdd] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [showView, setShowView] = useState(false);
  const [selected, setSelected] = useState<Resident | null>(
    null,
  );
  const [form, setForm] = useState(emptyForm);
  const PER_PAGE = 8;

  const ageInGroup = (age: number, group: string) => {
    if (group === "All") return true;
    if (group === "0-12") return age >= 0 && age <= 12;
    if (group === "13-24") return age >= 13 && age <= 24;
    if (group === "25-59") return age >= 25 && age <= 59;
    if (group === "60+") return age >= 60;
    return true;
  };

  const filtered = residents.filter((r) => {
    const q = search.toLowerCase();
    const matchSearch =
      !search ||
      `${r.firstName} ${r.middleName} ${r.lastName}`
        .toLowerCase()
        .includes(q) ||
      r.contact.includes(q) ||
      r.purok.toLowerCase().includes(q);
    return (
      matchSearch &&
      (purokFilter === "All" || r.purok === purokFilter) &&
      (genderFilter === "All" || r.gender === genderFilter) &&
      (statusFilter === "All" || r.status === statusFilter) &&
      ageInGroup(r.age, ageGroupFilter)
    );
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice(
    (page - 1) * PER_PAGE,
    page * PER_PAGE,
  );

  const handleAdd = () => {
    const newR = {
      ...form,
      id: residents.length + 1,
      age: Number(form.age) || 0,
    } as Resident;
    setResidents([newR, ...residents]);
    setShowAdd(false);
    setForm(emptyForm);
    toast.success("Resident added successfully");
  };

  const handleEdit = () => {
    setResidents(
      residents.map((r) =>
        r.id === selected?.id
          ? { ...r, ...form, age: Number(form.age) || r.age }
          : r,
      ),
    );
    setShowEdit(false);
    toast.success("Resident updated successfully");
  };

  const handleDelete = () => {
    setResidents(
      residents.filter((r) => r.id !== selected?.id),
    );
    setShowDelete(false);
    toast.success("Resident deleted");
  };

  const openEdit = (r: Resident) => {
    setSelected(r);
    setForm({
      ...r,
      age: String(r.age),
      birthDate: "",
      voter: r.voter,
    });
    setShowEdit(true);
  };

  const FormFields = ({
    f,
    setF,
  }: {
    f: typeof emptyForm;
    setF: (v: typeof emptyForm) => void;
  }) => (
    <div className="grid grid-cols-2 gap-4 py-2 max-h-[60vh] overflow-y-auto pr-2">
      {[
        ["First Name", "firstName"],
        ["Middle Name", "middleName"],
        ["Last Name", "lastName"],
        ["Birth Date", "birthDate", "date"],
        ["Contact Number", "contact"],
        ["Email", "email", "email"],
        ["Occupation", "occupation"],
      ].map(([label, key, type = "text"]) => (
        <div
          key={key as string}
          className={
            key === "occupation" || key === "email"
              ? "col-span-2"
              : ""
          }
        >
          <label
            style={{
              fontSize: "12.5px",
              fontWeight: 600,
              color: "#374151",
              display: "block",
              marginBottom: "4px",
            }}
          >
            {label}
          </label>
          <input
            type={type}
            value={(f as any)[key as string]}
            onChange={(e) =>
              setF({ ...f, [key as string]: e.target.value })
            }
            className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            style={{ fontSize: "13px" }}
          />
        </div>
      ))}
      {[
        ["Gender", "gender", ["Male", "Female"]],
        [
          "Civil Status",
          "civilStatus",
          ["Single", "Married", "Widowed", "Separated"],
        ],
        ["Purok", "purok", puroks.slice(1)],
        [
          "Status",
          "status",
          ["Active", "Inactive", "Deceased"],
        ],
      ].map(([label, key, opts]) => (
        <div key={key as string}>
          <label
            style={{
              fontSize: "12.5px",
              fontWeight: 600,
              color: "#374151",
              display: "block",
              marginBottom: "4px",
            }}
          >
            {label}
          </label>
          <select
            value={(f as any)[key as string]}
            onChange={(e) =>
              setF({ ...f, [key as string]: e.target.value })
            }
            className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            style={{ fontSize: "13px" }}
          >
            {(opts as string[]).map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </div>
      ))}
      <div className="col-span-2 flex items-center gap-2">
        <input
          type="checkbox"
          id="voter"
          checked={(f as any).voter}
          onChange={(e) =>
            setF({ ...f, voter: e.target.checked })
          }
          className="w-4 h-4 rounded border-slate-300 text-blue-600"
        />
        <label
          htmlFor="voter"
          style={{ fontSize: "13px", color: "#374151" }}
        >
          Registered Voter
        </label>
      </div>
      <div className="col-span-2">
        <label
          style={{
            fontSize: "12.5px",
            fontWeight: 600,
            color: "#374151",
            display: "block",
            marginBottom: "4px",
          }}
        >
          Notes
        </label>
        <textarea
          value={f.notes}
          onChange={(e) =>
            setF({ ...f, notes: e.target.value })
          }
          rows={2}
          className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          style={{ fontSize: "13px" }}
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            style={{
              fontSize: "22px",
              fontWeight: 700,
              color: "#0f172a",
            }}
          >
            Residents
          </h1>
          <p
            style={{
              fontSize: "13.5px",
              color: "#64748b",
              marginTop: "2px",
            }}
          >
            {filtered.length} residents found
          </p>
        </div>
        <Button
          onClick={() => {
            setForm(emptyForm);
            setShowAdd(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl"
        >
          <Plus className="w-4 h-4" /> Add Resident
        </Button>
      </div>

      {/* Filters */}
      <div
        className="bg-white rounded-2xl border border-slate-100 p-4"
        style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
      >
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search by name, contact, purok..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {[
              ["Purok", purokFilter, setPurokFilter, puroks],
              [
                "Gender",
                genderFilter,
                setGenderFilter,
                genders,
              ],
              [
                "Age Group",
                ageGroupFilter,
                setAgeGroupFilter,
                ageGroups,
              ],
              [
                "Status",
                statusFilter,
                setStatusFilter,
                statuses,
              ],
            ].map(([placeholder, value, setter, options]) => (
              <select
                key={placeholder as string}
                value={value as string}
                onChange={(e) => {
                  (setter as any)(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {(options as string[]).map((o) => (
                  <option key={o} value={o}>
                    {o === "All" ? `${placeholder}: All` : o}
                  </option>
                ))}
              </select>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div
        className="bg-white rounded-2xl border border-slate-100 overflow-hidden"
        style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr
                style={{
                  background: "#f8fafc",
                  borderBottom: "1px solid #e2e8f0",
                }}
              >
                {[
                  "Full Name",
                  "Age",
                  "Gender",
                  "Contact Number",
                  "Purok",
                  "Occupation",
                  "Status",
                  "Actions",
                ].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-left"
                    style={{
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "#64748b",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.map((r, i) => (
                <tr
                  key={r.id}
                  className="border-b border-slate-50 hover:bg-slate-50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <span
                          style={{
                            fontSize: "11px",
                            fontWeight: 700,
                            color: "#1d4ed8",
                          }}
                        >
                          {r.firstName[0]}
                          {r.lastName[0]}
                        </span>
                      </div>
                      <div>
                        <p
                          style={{
                            fontSize: "13px",
                            fontWeight: 600,
                            color: "#1e293b",
                          }}
                        >
                          {r.firstName} {r.lastName}
                        </p>
                        <p
                          style={{
                            fontSize: "11px",
                            color: "#94a3b8",
                          }}
                        >
                          {r.email || "—"}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td
                    className="px-4 py-3"
                    style={{
                      fontSize: "13px",
                      color: "#374151",
                    }}
                  >
                    {r.age}
                  </td>
                  <td
                    className="px-4 py-3"
                    style={{
                      fontSize: "13px",
                      color: "#374151",
                    }}
                  >
                    {r.gender}
                  </td>
                  <td
                    className="px-4 py-3"
                    style={{
                      fontSize: "13px",
                      color: "#374151",
                    }}
                  >
                    {r.contact}
                  </td>
                  <td
                    className="px-4 py-3"
                    style={{
                      fontSize: "13px",
                      color: "#374151",
                    }}
                  >
                    {r.purok}
                  </td>
                  <td
                    className="px-4 py-3"
                    style={{
                      fontSize: "13px",
                      color: "#374151",
                    }}
                  >
                    {r.occupation}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={r.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setSelected(r);
                          setShowView(true);
                        }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => openEdit(r)}
                        className="p-1.5 rounded-lg hover:bg-amber-50 text-slate-400 hover:text-amber-600 transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          setSelected(r);
                          setShowDelete(true);
                        }}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
          <p style={{ fontSize: "12.5px", color: "#94a3b8" }}>
            Showing{" "}
            {Math.min(
              (page - 1) * PER_PAGE + 1,
              filtered.length,
            )}
            –{Math.min(page * PER_PAGE, filtered.length)} of{" "}
            {filtered.length}
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from(
              { length: Math.min(5, totalPages) },
              (_, i) => {
                const p = i + 1;
                return (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`w-8 h-8 rounded-lg text-sm transition-colors ${page === p ? "bg-blue-600 text-white" : "hover:bg-slate-100 text-slate-600"}`}
                  >
                    {p}
                  </button>
                );
              },
            )}
            <button
              onClick={() =>
                setPage((p) => Math.min(totalPages, p + 1))
              }
              disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add Modal */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add New Resident</DialogTitle>
          </DialogHeader>
          <FormFields f={form} setF={setForm} />
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAdd(false)}
            >
              Cancel
            </Button>
            <Button
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleAdd}
            >
              Save Resident
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Modal */}
      <Dialog open={showEdit} onOpenChange={setShowEdit}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Resident</DialogTitle>
          </DialogHeader>
          <FormFields f={form} setF={setForm} />
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEdit(false)}
            >
              Cancel
            </Button>
            <Button
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleEdit}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Modal */}
      <Dialog open={showDelete} onOpenChange={setShowDelete}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete Resident</DialogTitle>
          </DialogHeader>
          <p style={{ fontSize: "14px", color: "#64748b" }}>
            Are you sure you want to delete{" "}
            <strong>
              {selected?.firstName} {selected?.lastName}
            </strong>
            ? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDelete(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Modal */}
      <Dialog open={showView} onOpenChange={setShowView}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Resident Details</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
                <div className="w-12 h-12 rounded-xl bg-blue-200 flex items-center justify-center">
                  <span
                    style={{
                      fontSize: "16px",
                      fontWeight: 700,
                      color: "#1d4ed8",
                    }}
                  >
                    {selected.firstName[0]}
                    {selected.lastName[0]}
                  </span>
                </div>
                <div>
                  <p
                    style={{
                      fontWeight: 700,
                      color: "#1e293b",
                    }}
                  >
                    {selected.firstName} {selected.middleName}{" "}
                    {selected.lastName}
                  </p>
                  <StatusBadge status={selected.status} />
                </div>
              </div>
              {[
                ["Age", selected.age],
                ["Gender", selected.gender],
                ["Civil Status", selected.civilStatus],
                ["Contact", selected.contact],
                ["Purok", selected.purok],
                ["Occupation", selected.occupation],
                ["Voter", selected.voter ? "Yes" : "No"],
                ["Notes", selected.notes || "—"],
              ].map(([k, v]) => (
                <div
                  key={k as string}
                  className="flex justify-between py-1 border-b border-slate-50"
                >
                  <span
                    style={{
                      fontSize: "13px",
                      color: "#64748b",
                    }}
                  >
                    {k}
                  </span>
                  <span
                    style={{
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#1e293b",
                    }}
                  >
                    {String(v)}
                  </span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowView(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}