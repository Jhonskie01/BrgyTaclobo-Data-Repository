import React, { useState } from 'react';
import { Plus, Search, Download, Eye, CheckCircle, Clock, XCircle, Award, Printer, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';

const certTypes = [
  'Barangay Clearance', 'Residency Certificate', 'Indigency Certificate',
  'Community Tax Certificate (Cedula)', 'Business Permit Endorsement',
  'Good Moral Character', 'SK Certification', 'PWD Endorsement', 'Senior Citizen Processing'
];

const initialCerts = [
  { id: 1, controlNo: 'BC-2026-001', type: 'Barangay Clearance', resident: 'Juan Dela Cruz', purpose: 'Employment', issued: 'May 28, 2026', status: 'Approved', issuedBy: 'Maria Santos' },
  { id: 2, controlNo: 'RC-2026-045', type: 'Residency Certificate', resident: 'Maria Clara Santos', purpose: 'School Enrollment', issued: 'May 27, 2026', status: 'Approved', issuedBy: 'Maria Santos' },
  { id: 3, controlNo: 'IC-2026-023', type: 'Indigency Certificate', resident: 'Roberto Reyes', purpose: 'Medical Assistance', issued: 'May 27, 2026', status: 'Pending', issuedBy: '—' },
  { id: 4, controlNo: 'BC-2026-002', type: 'Barangay Clearance', resident: 'Ana Gonzales', purpose: 'Bank Loan', issued: 'May 26, 2026', status: 'Approved', issuedBy: 'Juan Admin' },
  { id: 5, controlNo: 'GM-2026-011', type: 'Good Moral Character', resident: 'Carlos Garcia', purpose: 'Job Application', issued: 'May 26, 2026', status: 'Approved', issuedBy: 'Maria Santos' },
  { id: 6, controlNo: 'SK-2026-005', type: 'SK Certification', resident: 'Pedro Bautista Jr.', purpose: 'SK Activities', issued: 'May 25, 2026', status: 'Approved', issuedBy: 'Maria Santos' },
  { id: 7, controlNo: 'PW-2026-003', type: 'PWD Endorsement', resident: 'Jose Torres', purpose: 'PWD Benefits', issued: 'May 25, 2026', status: 'Processing', issuedBy: '—' },
  { id: 8, controlNo: 'CT-2026-089', type: 'Community Tax Certificate (Cedula)', resident: 'Rosa Flores', purpose: 'Annual Requirement', issued: 'May 24, 2026', status: 'Approved', issuedBy: 'Juan Admin' },
  { id: 9, controlNo: 'BP-2026-012', type: 'Business Permit Endorsement', resident: 'Elena Ramos', purpose: 'Business Permit Renewal', issued: 'May 23, 2026', status: 'Rejected', issuedBy: '—' },
];

type Cert = typeof initialCerts[0];

const StatusBadge = ({ status }: { status: string }) => {
  const styles: Record<string, string> = {
    Approved: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
    Pending: 'bg-amber-50 text-amber-700 border border-amber-200',
    Processing: 'bg-blue-50 text-blue-700 border border-blue-200',
    Rejected: 'bg-red-50 text-red-700 border border-red-200',
  };
  const icons: Record<string, React.ElementType> = {
    Approved: CheckCircle, Pending: Clock, Processing: Clock, Rejected: XCircle
  };
  const Icon = icons[status] || Clock;
  return (
    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full w-fit ${styles[status] || 'bg-slate-100 text-slate-600'}`}
      style={{ fontSize: '11.5px', fontWeight: 500 }}>
      <Icon className="w-3 h-3" />
      {status}
    </span>
  );
};

const emptyForm = { type: certTypes[0], resident: '', purpose: '', amount: '50.00' };

export function CertificatesView() {
  const [certs, setCerts] = useState(initialCerts);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [showIssue, setShowIssue] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [selected, setSelected] = useState<Cert | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [searchControl, setSearchControl] = useState('');
  const PER_PAGE = 8;

  const filtered = certs.filter(c => {
    const q = search.toLowerCase();
    const match = !search || c.resident.toLowerCase().includes(q) || c.controlNo.toLowerCase().includes(q) || c.type.toLowerCase().includes(q);
    return match && (statusFilter === 'All' || c.status === statusFilter) && (typeFilter === 'All' || c.type === typeFilter);
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleIssue = () => {
    const prefix = { 'Barangay Clearance': 'BC', 'Residency Certificate': 'RC', 'Indigency Certificate': 'IC', 'Community Tax Certificate (Cedula)': 'CT', 'Business Permit Endorsement': 'BP', 'Good Moral Character': 'GM', 'SK Certification': 'SK', 'PWD Endorsement': 'PW', 'Senior Citizen Processing': 'SC' }[form.type] || 'XX';
    const newC = { id: certs.length + 1, controlNo: `${prefix}-2026-${String(certs.length + 1).padStart(3, '0')}`, type: form.type, resident: form.resident, purpose: form.purpose, issued: 'May 29, 2026', status: 'Pending', issuedBy: '—' };
    setCerts([newC, ...certs]);
    setShowIssue(false);
    setForm(emptyForm);
    toast.success('Certificate request created');
  };

  const stats = [
    { label: 'Total Issued', value: certs.filter(c => c.status === 'Approved').length, color: '#10b981', bg: '#ecfdf5' },
    { label: 'Pending', value: certs.filter(c => c.status === 'Pending').length, color: '#f59e0b', bg: '#fffbeb' },
    { label: 'Processing', value: certs.filter(c => c.status === 'Processing').length, color: '#3b82f6', bg: '#eff6ff' },
    { label: 'Rejected', value: certs.filter(c => c.status === 'Rejected').length, color: '#ef4444', bg: '#fef2f2' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Certificates & Clearances</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>Manage barangay certificate requests</p>
        </div>
        <Button onClick={() => setShowIssue(true)} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <Plus className="w-4 h-4" /> Issue Certificate
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <p style={{ fontSize: '28px', fontWeight: 700, color: s.color }}>{s.value}</p>
            <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>{s.label}</p>
            <div className="mt-2 h-1.5 rounded-full bg-slate-100 overflow-hidden">
              <div className="h-full rounded-full transition-all" style={{ width: `${(s.value / certs.length) * 100}%`, background: s.color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Services grid */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a', marginBottom: '12px' }}>Available Services</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {certTypes.map((type, i) => (
            <button key={i}
              onClick={() => { setForm({ ...emptyForm, type }); setShowIssue(true); }}
              className="p-3 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all text-left group">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center mb-2 group-hover:bg-blue-200 transition-colors">
                <Award className="w-4 h-4 text-blue-600" />
              </div>
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#1e293b', lineHeight: 1.3 }}>{type}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search by control number, resident, type..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            {['All', 'Approved', 'Pending', 'Processing', 'Rejected'].map(s => <option key={s}>{s === 'All' ? 'Status: All' : s}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['Control No.', 'Certificate Type', 'Resident', 'Purpose', 'Date Issued', 'Issued By', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.map(c => (
                <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <span style={{ fontSize: '12.5px', fontWeight: 700, color: '#1d4ed8', fontFamily: 'monospace' }}>{c.controlNo}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-purple-500 flex-shrink-0" />
                      <span style={{ fontSize: '13px', color: '#1e293b' }}>{c.type}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', fontWeight: 500, color: '#374151' }}>{c.resident}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{c.purpose}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{c.issued}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{c.issuedBy}</td>
                  <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setSelected(c); setShowPreview(true); }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 transition-colors">
                        <Printer className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-purple-50 text-slate-400 hover:text-purple-600 transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
          <p style={{ fontSize: '12.5px', color: '#94a3b8' }}>
            Showing {Math.min((page - 1) * PER_PAGE + 1, filtered.length)}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}
          </p>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => (
              <button key={i + 1} onClick={() => setPage(i + 1)}
                className={`w-8 h-8 rounded-lg text-sm ${page === i + 1 ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-600'}`}>{i + 1}</button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Issue Modal */}
      <Dialog open={showIssue} onOpenChange={setShowIssue}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Issue Certificate</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Certificate Type</label>
              <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {certTypes.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Resident Name</label>
              <input value={form.resident} onChange={e => setForm({ ...form, resident: e.target.value })}
                placeholder="Enter full name"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Purpose</label>
              <input value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })}
                placeholder="e.g., Employment, School Enrollment"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Fee (₱)</label>
              <input value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowIssue(false)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleIssue}>Create Request</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Modal */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Certificate Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-3">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border border-blue-100 text-center">
                <Award className="w-10 h-10 text-blue-600 mx-auto mb-2" />
                <p style={{ fontWeight: 700, color: '#1e293b', fontSize: '15px' }}>{selected.type}</p>
                <p style={{ fontSize: '12px', color: '#64748b', fontFamily: 'monospace' }}>{selected.controlNo}</p>
              </div>
              {[['Resident', selected.resident], ['Purpose', selected.purpose], ['Date Issued', selected.issued], ['Issued By', selected.issuedBy], ['Status', selected.status]].map(([k, v]) => (
                <div key={k as string} className="flex justify-between py-1.5 border-b border-slate-50">
                  <span style={{ fontSize: '13px', color: '#64748b' }}>{k}</span>
                  <span style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b' }}>{v}</span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreview(false)}>Close</Button>
            <Button className="bg-blue-600 hover:bg-blue-700 gap-2"><Printer className="w-4 h-4" /> Print</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
