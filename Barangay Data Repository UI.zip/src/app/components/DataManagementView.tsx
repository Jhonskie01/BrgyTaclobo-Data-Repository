import React, { useState } from 'react';
import { Database, Upload, Download, RefreshCw, Table2, FileSpreadsheet, Search, Filter, Trash2, Edit, CheckSquare } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';

const dataSections = [
  { id: 'residents', label: 'Residents', icon: '👥', count: 4821, size: '2.4 MB', lastUpdated: 'May 29, 2026' },
  { id: 'households', label: 'Households', icon: '🏠', count: 1247, size: '892 KB', lastUpdated: 'May 28, 2026' },
  { id: 'certificates', label: 'Certificates', icon: '📜', count: 389, size: '456 KB', lastUpdated: 'May 29, 2026' },
  { id: 'incidents', label: 'Incidents', icon: '⚠️', count: 75, size: '234 KB', lastUpdated: 'May 28, 2026' },
  { id: 'projects', label: 'Projects', icon: '📁', count: 14, size: '178 KB', lastUpdated: 'May 25, 2026' },
  { id: 'documents', label: 'Documents', icon: '📄', count: 1054, size: '45.6 MB', lastUpdated: 'May 29, 2026' },
];

const dbOperations = [
  { title: 'Export Data', desc: 'Export all data to Excel or CSV', icon: Download, color: '#059669', bg: '#ecfdf5', action: 'export' },
  { title: 'Import Data', desc: 'Import data from CSV or Excel file', icon: Upload, color: '#1d4ed8', bg: '#eff6ff', action: 'import' },
  { title: 'Refresh Cache', desc: 'Clear system cache and reload', icon: RefreshCw, color: '#7c3aed', bg: '#f5f3ff', action: 'refresh' },
  { title: 'Optimize DB', desc: 'Run database optimization', icon: Database, color: '#d97706', bg: '#fffbeb', action: 'optimize' },
];

const recentOps = [
  { op: 'Export', table: 'Residents', user: 'Maria Santos', date: 'May 29, 2026 10:15 AM', status: 'Success' },
  { op: 'Import', table: 'Households', user: 'Ana Cruz', date: 'May 28, 2026 02:30 PM', status: 'Success' },
  { op: 'Optimize', table: 'All Tables', user: 'System', date: 'May 27, 2026 12:00 AM', status: 'Success' },
  { op: 'Export', table: 'Certificates', user: 'Pedro Santos', date: 'May 26, 2026 04:00 PM', status: 'Success' },
  { op: 'Refresh', table: 'Cache', user: 'Maria Santos', date: 'May 25, 2026 09:00 AM', status: 'Success' },
];

export function DataManagementView() {
  const [search, setSearch] = useState('');

  const handleOperation = (action: string) => {
    const messages: Record<string, string> = {
      export: 'Exporting data to Excel...',
      import: 'Opening file selector...',
      refresh: 'Cache refreshed successfully!',
      optimize: 'Database optimization started...',
    };
    toast.success(messages[action] || 'Operation started');
  };

  const filteredSections = dataSections.filter(s =>
    !search || s.label.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Data Management</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>Database operations and data administration</p>
        </div>
      </div>

      {/* Database status */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-6 text-white"
        style={{ boxShadow: '0 8px 24px rgba(29,78,216,0.3)' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <p style={{ fontWeight: 700, fontSize: '16px' }}>Database Status</p>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span style={{ fontSize: '13px', opacity: 0.85 }}>Online & Healthy</span>
              </div>
            </div>
          </div>
          <div className="hidden md:grid grid-cols-3 gap-6 text-right">
            {[['Total Records', '7,600+'], ['Storage Used', '52.3 MB'], ['Last Backup', 'Today 08:00 AM']].map(([k, v]) => (
              <div key={k as string}>
                <p style={{ fontSize: '18px', fontWeight: 700 }}>{v}</p>
                <p style={{ fontSize: '12px', opacity: 0.7 }}>{k}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick operations */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {dbOperations.map((op, i) => {
          const Icon = op.icon;
          return (
            <button key={i} onClick={() => handleOperation(op.action)}
              className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all text-left group"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform"
                style={{ background: op.bg }}>
                <Icon className="w-5 h-5" style={{ color: op.color }} />
              </div>
              <p style={{ fontSize: '13.5px', fontWeight: 600, color: '#0f172a' }}>{op.title}</p>
              <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '2px' }}>{op.desc}</p>
            </button>
          );
        })}
      </div>

      {/* Data tables overview */}
      <div className="bg-white rounded-2xl border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Data Tables</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Filter tables..."
              className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              style={{ fontSize: '13px' }} />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['Table', 'Records', 'Size', 'Last Updated', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredSections.map(s => (
                <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span style={{ fontSize: '18px' }}>{s.icon}</span>
                      <div>
                        <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{s.label}</p>
                        <p style={{ fontSize: '11.5px', color: '#94a3b8', fontFamily: 'monospace' }}>tbl_{s.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-lg" style={{ fontSize: '12.5px', fontWeight: 600 }}>
                      {s.count.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{s.size}</td>
                  <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b' }}>{s.lastUpdated}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => toast.success(`Exporting ${s.label} data...`)}
                        className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors"
                        style={{ fontSize: '12px' }}>
                        <Download className="w-3.5 h-3.5" /> Export
                      </button>
                      <button onClick={() => toast.success(`Truncate ${s.label} requested. Confirm in modal.`)}
                        className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-600 transition-colors"
                        style={{ fontSize: '12px' }}>
                        <Trash2 className="w-3.5 h-3.5" /> Clear
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent operations */}
      <div className="bg-white rounded-2xl border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="p-5 border-b border-slate-100">
          <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Recent Operations</h3>
        </div>
        <div className="divide-y divide-slate-50">
          {recentOps.map((op, i) => (
            <div key={i} className="flex items-center justify-between px-5 py-3 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                  {op.op === 'Export' ? <Download className="w-4 h-4 text-blue-600" /> :
                    op.op === 'Import' ? <Upload className="w-4 h-4 text-blue-600" /> :
                      op.op === 'Optimize' ? <Database className="w-4 h-4 text-blue-600" /> :
                        <RefreshCw className="w-4 h-4 text-blue-600" />}
                </div>
                <div>
                  <p style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b' }}>{op.op} — {op.table}</p>
                  <p style={{ fontSize: '11.5px', color: '#94a3b8' }}>by {op.user}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-full" style={{ fontSize: '11.5px', fontWeight: 500 }}>
                  {op.status}
                </span>
                <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '2px' }}>{op.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
