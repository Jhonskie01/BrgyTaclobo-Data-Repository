import React from "react";
import {
  LayoutDashboard,
  Users,
  Home,
  FileText,
  Award,
  AlertTriangle,
  FolderOpen,
  BarChart3,
  Database,
  Bell,
  UserCog,
  HardDrive,
  Settings,
  LogOut,
  Shield,
  X,
} from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
}

interface NavSection {
  label?: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    items: [
      {
        id: "dashboard",
        label: "Dashboard",
        icon: LayoutDashboard,
      },
    ],
  },
  {
    label: "MANAGEMENT",
    items: [
      { id: "residents", label: "Residents", icon: Users },
      { id: "households", label: "Households", icon: Home },
      { id: "documents", label: "Documents", icon: FileText },
      {
        id: "certificates",
        label: "Certificates & Clearances",
        icon: Award,
      },
      {
        id: "incidents",
        label: "Incident / Blotter",
        icon: AlertTriangle,
        badge: 5,
      },
      { id: "projects", label: "Projects", icon: FolderOpen },
    ],
  },
  {
    label: "ANALYTICS",
    items: [
      { id: "reports", label: "Reports", icon: BarChart3 },
      { id: "data", label: "Data Management", icon: Database },
    ],
  },
  {
    label: "SYSTEM",
    items: [
      {
        id: "notifications",
        label: "Notifications",
        icon: Bell,
        badge: 8,
      },
      { id: "users", label: "User Management", icon: UserCog },
      {
        id: "backup",
        label: "Backup & Restore",
        icon: HardDrive,
      },
      { id: "settings", label: "Settings", icon: Settings },
    ],
  },
];

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout?: () => void;
}

export function Sidebar({
  currentView,
  onNavigate,
  isOpen,
  onClose,
  onLogout,
}: SidebarProps) {
  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={[
          "fixed top-0 left-0 h-full w-64 z-50 flex flex-col transition-transform duration-300",
          "lg:translate-x-0 lg:relative lg:z-auto",
          isOpen ? "translate-x-0" : "-translate-x-full",
        ].join(" ")}
        style={{
          background:
            "linear-gradient(180deg, #0c2461 0%, #1a3a6b 100%)",
        }}
      >
        {/* Brand */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: "rgba(59,130,246,0.25)",
                border: "1px solid rgba(59,130,246,0.4)",
              }}
            >
              <Shield className="w-5 h-5 text-blue-300" />
            </div>
            <div>
              <p
                style={{
                  color: "white",
                  fontSize: "13px",
                  fontWeight: 700,
                  lineHeight: 1.2,
                }}
              >
                Brgy. Taclobo
              </p>
              <p
                style={{ color: "#93c5fd", fontSize: "10.5px" }}
              >
                Data Repository System
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2.5 space-y-0.5">
          {navSections.map((section, idx) => (
            <div key={idx} className={idx > 0 ? "pt-3" : ""}>
              {section.label && (
                <p
                  style={{
                    color: "#60a5fa",
                    fontSize: "10px",
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                  }}
                  className="px-3 pb-1.5 uppercase"
                >
                  {section.label}
                </p>
              )}
              {section.items.map((item) => {
                const Icon = item.icon;
                const active = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      onClose();
                    }}
                    className={[
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200",
                      active
                        ? "text-white"
                        : "text-blue-200 hover:text-white hover:bg-white/10",
                    ].join(" ")}
                    style={
                      active
                        ? {
                            background:
                              "linear-gradient(135deg, #1d4ed8, #2563eb)",
                            boxShadow:
                              "0 4px 12px rgba(37,99,235,0.4)",
                          }
                        : {}
                    }
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span
                      className="flex-1 text-left"
                      style={{ fontSize: "13.5px" }}
                    >
                      {item.label}
                    </span>
                    {item.badge && (
                      <span
                        className="bg-red-500 text-white rounded-full px-1.5 min-w-[20px] text-center"
                        style={{ fontSize: "10px" }}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-white/10">
          <div className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-white/10 cursor-pointer transition-colors">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
              <span
                style={{
                  color: "white",
                  fontSize: "12px",
                  fontWeight: 700,
                }}
              >
                MA
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p
                style={{
                  color: "white",
                  fontSize: "13px",
                  fontWeight: 600,
                }}
                className="truncate"
              >
                Cris Jhon Lloyd Padilla
              </p>
              <p style={{ color: "#93c5fd", fontSize: "11px" }}>
                Administrator
              </p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl transition-colors mt-1"
            style={{ color: "#f87171", fontSize: "13px" }}
            onMouseEnter={(e) =>
              ((
                e.currentTarget as HTMLElement
              ).style.background = "rgba(239,68,68,0.15)")
            }
            onMouseLeave={(e) =>
              ((
                e.currentTarget as HTMLElement
              ).style.background = "")
            }
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}