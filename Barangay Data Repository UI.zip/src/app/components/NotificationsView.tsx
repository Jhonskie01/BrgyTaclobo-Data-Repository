import React, { useState } from 'react';
import { Bell, Check, CheckCheck, Trash2, Filter, Users, Award, AlertTriangle, FileText, FolderOpen, HardDrive } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';

type NotifType = 'info' | 'success' | 'warning' | 'error';

const initialNotifs = [
  { id: 1, type: 'info' as NotifType, title: 'New Resident Registration', message: 'Juan Dela Cruz submitted a new resident registration form for review.', time: '2 min ago', read: false, icon: Users, category: 'Residents' },
  { id: 2, type: 'info' as NotifType, title: 'Certificate Request', message: 'Maria Santos is requesting a Barangay Clearance certificate.', time: '15 min ago', read: false, icon: Award, category: 'Certificates' },
  { id: 3, type: 'warning' as NotifType, title: 'Incident Report Updated', message: 'Blotter report BLT-2026-091 status has been updated to Under Investigation.', time: '1 hr ago', read: false, icon: AlertTriangle, category: 'Incidents' },
  { id: 4, type: 'success' as NotifType, title: 'Backup Completed', message: 'Daily backup completed successfully. File size: 4.2 MB.', time: '3 hrs ago', read: true, icon: HardDrive, category: 'System' },
  { id: 5, type: 'info' as NotifType, title: 'New Project Proposal', message: 'A new project proposal for "Drainage Improvement Phase 2" has been submitted.', time: '5 hrs ago', read: true, icon: FolderOpen, category: 'Projects' },
  { id: 6, type: 'info' as NotifType, title: 'Document Uploaded', message: '12 new documents have been uploaded to the repository by Ana Cruz.', time: '7 hrs ago', read: true, icon: FileText, category: 'Documents' },
  { id: 7, type: 'success' as NotifType, title: 'Certificate Issued', message: 'Certificate of Residency has been successfully issued to Roberto Reyes.', time: '1 day ago', read: true, icon: Award, category: 'Certificates' },
  { id: 8, type: 'warning' as NotifType, title: 'Pending Requests', message: 'There are 8 pending certificate requests awaiting approval.', time: '1 day ago', read: true, icon: Award, category: 'Certificates' },
  { id: 9, type: 'info' as NotifType, title: 'New Household Added', message: 'Household HH-2026-049 has been registered under Purok 5.', time: '2 days ago', read: true, icon: Users, category: 'Households' },
  { id: 10, type: 'success' as NotifType, title: 'Data Import Complete', message: 'Resident data import from previous system completed. 234 records imported.', time: '3 days ago', read: true, icon: FileText, category: 'System' },
];

type Notification = typeof initialNotifs[0];

const typeColors: Record<NotifType, { icon: string; bg: string; dot: string }> = {
  info: { icon: '#3b82f6', bg: '#eff6ff', dot: '#3b82f6' },
  success: { icon: '#10b981', bg: '#ecfdf5', dot: '#10b981' },
  warning: { icon: '#f59e0b', bg: '#fffbeb', dot: '#f59e0b' },
  error: { icon: '#ef4444', bg: '#fef2f2', dot: '#ef4444' },
};

const categories = ['All', 'Residents', 'Households', 'Certificates', 'Incidents', 'Projects', 'Documents', 'System'];

export function NotificationsView() {
  const [notifications, setNotifications] = useState(initialNotifs);
  const [filter, setFilter] = useState('All');
  const [readFilter, setReadFilter] = useState<'all' | 'unread' | 'read'>('all');

  const filtered = notifications.filter(n => {
    return (filter === 'All' || n.category === filter) &&
      (readFilter === 'all' || (readFilter === 'unread' ? !n.read : n.read));
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const markRead = (id: number) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    toast.success('All notifications marked as read');
  };

  const deleteNotif = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
    toast.success('Notification deleted');
  };

  const clearAll = () => {
    setNotifications([]);
    toast.success('All notifications cleared');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Notifications</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>
            {unreadCount > 0 ? `${unreadCount} unread notifications` : 'All caught up!'}
          </p>
        </div>
        <div className="flex gap-2">
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllRead} className="gap-2 rounded-xl" style={{ fontSize: '13px' }}>
              <CheckCheck className="w-4 h-4" /> Mark all read
            </Button>
          )}
          <Button variant="outline" onClick={clearAll} className="gap-2 rounded-xl text-red-600 border-red-200 hover:bg-red-50" style={{ fontSize: '13px' }}>
            <Trash2 className="w-4 h-4" /> Clear all
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total', value: notifications.length, color: '#1d4ed8', bg: '#eff6ff' },
          { label: 'Unread', value: unreadCount, color: '#dc2626', bg: '#fef2f2' },
          { label: 'Read', value: notifications.filter(n => n.read).length, color: '#059669', bg: '#ecfdf5' },
          { label: 'Today', value: notifications.filter(n => n.time.includes('min') || n.time.includes('hr')).length, color: '#7c3aed', bg: '#f5f3ff' },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <p style={{ fontSize: '26px', fontWeight: 700, color: s.color }}>{s.value}</p>
            <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-wrap gap-3 items-center">
          <div className="flex gap-1">
            {(['all', 'unread', 'read'] as const).map(f => (
              <button key={f} onClick={() => setReadFilter(f)}
                className={`px-3 py-1.5 rounded-lg transition-colors capitalize ${readFilter === f ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                style={{ fontSize: '12.5px', fontWeight: 500 }}>
                {f}
              </button>
            ))}
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {categories.map(cat => (
              <button key={cat} onClick={() => setFilter(cat)}
                className={`px-3 py-1.5 rounded-lg transition-colors ${filter === cat ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                style={{ fontSize: '12px' }}>
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Notification list */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <Bell className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p style={{ fontSize: '14px', color: '#94a3b8' }}>No notifications</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50">
            {filtered.map(n => {
              const Icon = n.icon;
              const tc = typeColors[n.type];
              return (
                <div key={n.id}
                  className={`flex items-start gap-4 px-5 py-4 hover:bg-slate-50 transition-colors ${!n.read ? 'bg-blue-50/30' : ''}`}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: tc.bg }}>
                    <Icon className="w-5 h-5" style={{ color: tc.icon }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <p style={{ fontSize: '13.5px', fontWeight: n.read ? 500 : 700, color: '#1e293b' }}>{n.title}</p>
                          {!n.read && <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: tc.dot }} />}
                        </div>
                        <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px', lineHeight: 1.5 }}>{n.message}</p>
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded-lg" style={{ fontSize: '11px' }}>{n.category}</span>
                          <span style={{ fontSize: '11.5px', color: '#94a3b8' }}>{n.time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {!n.read && (
                      <button onClick={() => markRead(n.id)}
                        className="p-1.5 rounded-lg hover:bg-blue-100 text-blue-500 transition-colors" title="Mark as read">
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    <button onClick={() => deleteNotif(n.id)}
                      className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors" title="Delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
