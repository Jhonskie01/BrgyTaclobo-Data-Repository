import React, { useState, useRef } from 'react';
import { Upload, Search, FileText, Image, File, Download, Trash2, Eye, Grid, List, FolderOpen, X } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';

const docTypes = ['All', 'Certificate', 'ID', 'Birth Record', 'Land Title', 'Business Permit', 'Photo', 'Other'];

const initialDocs = [
  { id: 1, name: 'Barangay_Clearance_001.pdf', type: 'Certificate', size: '245 KB', date: 'May 28, 2026', resident: 'Juan Dela Cruz', icon: 'pdf', ext: 'pdf' },
  { id: 2, name: 'Birth_Certificate_Maria.pdf', type: 'Birth Record', size: '189 KB', date: 'May 27, 2026', resident: 'Maria Santos', icon: 'pdf', ext: 'pdf' },
  { id: 3, name: 'Profile_Photo_Pedro.jpg', type: 'Photo', size: '1.2 MB', date: 'May 26, 2026', resident: 'Pedro Bautista', icon: 'img', ext: 'jpg' },
  { id: 4, name: 'Land_Title_Reyes.docx', type: 'Land Title', size: '890 KB', date: 'May 25, 2026', resident: 'Roberto Reyes', icon: 'doc', ext: 'docx' },
  { id: 5, name: 'Business_Permit_Flores.pdf', type: 'Business Permit', size: '567 KB', date: 'May 24, 2026', resident: 'Rosa Flores', icon: 'pdf', ext: 'pdf' },
  { id: 6, name: 'Indigency_Certificate_Ramos.pdf', type: 'Certificate', size: '198 KB', date: 'May 23, 2026', resident: 'Elena Ramos', icon: 'pdf', ext: 'pdf' },
  { id: 7, name: 'NBI_Clearance_Garcia.jpg', type: 'ID', size: '765 KB', date: 'May 22, 2026', resident: 'Carlos Garcia', icon: 'img', ext: 'jpg' },
  { id: 8, name: 'Voter_ID_Gonzales.jpg', type: 'ID', size: '654 KB', date: 'May 21, 2026', resident: 'Ana Gonzales', icon: 'img', ext: 'jpg' },
  { id: 9, name: 'SK_Certification_001.pdf', type: 'Certificate', size: '312 KB', date: 'May 20, 2026', resident: 'Carlos Garcia', icon: 'pdf', ext: 'pdf' },
  { id: 10, name: 'Community_Meeting_Minutes.docx', type: 'Other', size: '456 KB', date: 'May 19, 2026', resident: '—', icon: 'doc', ext: 'docx' },
  { id: 11, name: 'PWD_ID_Torres.jpg', type: 'ID', size: '543 KB', date: 'May 18, 2026', resident: 'Jose Torres', icon: 'img', ext: 'jpg' },
  { id: 12, name: 'Good_Moral_Bautista.pdf', type: 'Certificate', size: '287 KB', date: 'May 17, 2026', resident: 'Pedro Bautista', icon: 'pdf', ext: 'pdf' },
];

type Doc = typeof initialDocs[0];

const IconEl = ({ icon, ext }: { icon: string; ext: string }) => {
  const colors: Record<string, string> = { pdf: '#ef4444', doc: '#2563eb', img: '#10b981', default: '#64748b' };
  const color = colors[icon] || colors.default;
  return (
    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${color}15` }}>
      {icon === 'img' ? <Image className="w-5 h-5" style={{ color }} /> :
        icon === 'pdf' ? <FileText className="w-5 h-5" style={{ color }} /> :
          <File className="w-5 h-5" style={{ color }} />}
    </div>
  );
};

const extColor = (ext: string) => {
  const m: Record<string, string> = { pdf: 'bg-red-50 text-red-600 border border-red-200', jpg: 'bg-emerald-50 text-emerald-600 border border-emerald-200', docx: 'bg-blue-50 text-blue-600 border border-blue-200' };
  return m[ext] || 'bg-slate-100 text-slate-600';
};

export function DocumentsView() {
  const [docs, setDocs] = useState(initialDocs);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [dragging, setDragging] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [selected, setSelected] = useState<Doc | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filtered = docs.filter(d => {
    const q = search.toLowerCase();
    const match = !search || d.name.toLowerCase().includes(q) || d.resident.toLowerCase().includes(q);
    return match && (typeFilter === 'All' || d.type === typeFilter);
  });

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'file';
      const icon = ['jpg', 'jpeg', 'png', 'gif'].includes(ext) ? 'img' : ext === 'pdf' ? 'pdf' : 'doc';
      setDocs(prev => [{
        id: prev.length + 1,
        name: file.name,
        type: 'Other',
        size: `${(file.size / 1024).toFixed(0)} KB`,
        date: 'May 29, 2026',
        resident: '—',
        icon,
        ext
      }, ...prev]);
    });
    toast.success(`${files.length} file(s) uploaded successfully`);
  };

  const handleDelete = (id: number) => {
    setDocs(docs.filter(d => d.id !== id));
    toast.success('File deleted');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Documents</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>{filtered.length} files in repository</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setViewMode('grid')}
            className={`p-2 rounded-xl border transition-colors ${viewMode === 'grid' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}>
            <Grid className="w-4 h-4" />
          </button>
          <button onClick={() => setViewMode('list')}
            className={`p-2 rounded-xl border transition-colors ${viewMode === 'list' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}>
            <List className="w-4 h-4" />
          </button>
          <Button onClick={() => fileInputRef.current?.click()} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
            <Upload className="w-4 h-4" /> Upload File
          </Button>
          <input ref={fileInputRef} type="file" multiple className="hidden"
            onChange={e => {
              const files = Array.from(e.target.files || []);
              files.forEach(file => {
                const ext = file.name.split('.').pop()?.toLowerCase() || 'file';
                const icon = ['jpg', 'jpeg', 'png'].includes(ext) ? 'img' : ext === 'pdf' ? 'pdf' : 'doc';
                setDocs(prev => [{ id: prev.length + 1, name: file.name, type: 'Other', size: `${(file.size / 1024).toFixed(0)} KB`, date: 'May 29, 2026', resident: '—', icon, ext }, ...prev]);
              });
              if (files.length) toast.success(`${files.length} file(s) uploaded`);
            }} />
        </div>
      </div>

      {/* Upload area */}
      <div
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${dragging ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-blue-400 hover:bg-slate-50'}`}>
        <div className="w-14 h-14 rounded-2xl bg-blue-100 flex items-center justify-center mx-auto mb-3">
          <Upload className="w-7 h-7 text-blue-600" />
        </div>
        <p style={{ fontWeight: 600, color: '#1e293b', fontSize: '14px' }}>
          {dragging ? 'Drop files here' : 'Drag & drop files here or click to browse'}
        </p>
        <p style={{ fontSize: '12.5px', color: '#94a3b8', marginTop: '4px' }}>
          Supports PDF, DOCX, JPG, PNG — Max 50MB per file
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search files by name or resident..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            {docTypes.map(t => <option key={t}>{t === 'All' ? 'Type: All' : t}</option>)}
          </select>
        </div>
      </div>

      {/* File listing */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filtered.map(d => (
            <div key={d.id} className="bg-white rounded-2xl border border-slate-100 p-4 hover:shadow-md transition-all cursor-pointer group"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}
              onClick={() => { setSelected(d); setShowPreview(true); }}>
              <div className="aspect-square rounded-xl bg-slate-50 flex items-center justify-center mb-3 relative overflow-hidden">
                <IconEl icon={d.icon} ext={d.ext} />
                <div className="absolute inset-0 bg-blue-600/0 group-hover:bg-blue-600/10 transition-colors rounded-xl flex items-center justify-center">
                  <Eye className="w-5 h-5 text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <p style={{ fontSize: '12px', fontWeight: 600, color: '#1e293b' }} className="truncate">{d.name}</p>
              <div className="flex items-center justify-between mt-1">
                <span className={`px-1.5 py-0.5 rounded ${extColor(d.ext)}`} style={{ fontSize: '10px', fontWeight: 600, textTransform: 'uppercase' }}>{d.ext}</span>
                <span style={{ fontSize: '11px', color: '#94a3b8' }}>{d.size}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['File Name', 'Type', 'Resident/Linked', 'Size', 'Upload Date', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(d => (
                <tr key={d.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <IconEl icon={d.icon} ext={d.ext} />
                      <div>
                        <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{d.name}</p>
                        <span className={`px-1.5 py-0.5 rounded ${extColor(d.ext)}`} style={{ fontSize: '10px', fontWeight: 700, textTransform: 'uppercase' }}>{d.ext}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3"><span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-lg" style={{ fontSize: '12px' }}>{d.type}</span></td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{d.resident}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{d.size}</td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{d.date}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setSelected(d); setShowPreview(true); }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(d.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Preview Modal */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>File Preview</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div className="aspect-video bg-slate-100 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <IconEl icon={selected.icon} ext={selected.ext} />
                  <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '8px' }}>Preview not available</p>
                </div>
              </div>
              <div className="space-y-2">
                {[['File Name', selected.name], ['Type', selected.type], ['Size', selected.size], ['Resident', selected.resident], ['Upload Date', selected.date]].map(([k, v]) => (
                  <div key={k as string} className="flex justify-between py-1.5 border-b border-slate-50">
                    <span style={{ fontSize: '13px', color: '#64748b' }}>{k}</span>
                    <span style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b' }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreview(false)}>Close</Button>
            <Button className="bg-blue-600 hover:bg-blue-700 gap-2"><Download className="w-4 h-4" /> Download</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
