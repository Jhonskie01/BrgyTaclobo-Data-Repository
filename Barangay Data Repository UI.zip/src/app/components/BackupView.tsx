import React, { useState } from 'react';
import { HardDrive, Download, Upload, Clock, CheckCircle, AlertTriangle, RefreshCw, Database, Shield, Cloud } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Progress } from './ui/progress';
import { toast } from 'sonner';

const backupHistory = [
  { id: 1, name: 'backup_20260529_080000.sql', size: '4.2 MB', date: 'May 29, 2026 08:00 AM', type: 'Scheduled', status: 'Success' },
  { id: 2, name: 'backup_20260528_080000.sql', size: '4.1 MB', date: 'May 28, 2026 08:00 AM', type: 'Scheduled', status: 'Success' },
  { id: 3, name: 'backup_20260527_manual.sql', size: '4.0 MB', date: 'May 27, 2026 03:45 PM', type: 'Manual', status: 'Success' },
  { id: 4, name: 'backup_20260526_080000.sql', size: '3.9 MB', date: 'May 26, 2026 08:00 AM', type: 'Scheduled', status: 'Success' },
  { id: 5, name: 'backup_20260525_080000.sql', size: '3.8 MB', date: 'May 25, 2026 08:00 AM', type: 'Scheduled', status: 'Failed' },
  { id: 6, name: 'backup_20260524_080000.sql', size: '3.7 MB', date: 'May 24, 2026 08:00 AM', type: 'Scheduled', status: 'Success' },
  { id: 7, name: 'backup_20260523_manual.sql', size: '3.7 MB', date: 'May 23, 2026 10:30 AM', type: 'Manual', status: 'Success' },
];

const stats = [
  { label: 'Last Backup', value: 'Today 08:00 AM', icon: Clock, color: '#1d4ed8', bg: '#eff6ff' },
  { label: 'Total Backups', value: '156 files', icon: Database, color: '#7c3aed', bg: '#f5f3ff' },
  { label: 'Storage Used', value: '124 MB', icon: HardDrive, color: '#d97706', bg: '#fffbeb' },
  { label: 'Success Rate', value: '98.7%', icon: Shield, color: '#059669', bg: '#ecfdf5' },
];

export function BackupView() {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [showRestore, setShowRestore] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<typeof backupHistory[0] | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreProgress, setRestoreProgress] = useState(0);

  const handleBackup = () => {
    setIsBackingUp(true);
    setBackupProgress(0);
    const interval = setInterval(() => {
      setBackupProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsBackingUp(false);
          toast.success('Backup completed successfully!');
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleRestore = () => {
    setIsRestoring(true);
    setRestoreProgress(0);
    const interval = setInterval(() => {
      setRestoreProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRestoring(false);
          setShowRestore(false);
          toast.success('Restore completed successfully!');
          return 100;
        }
        return prev + 8;
      });
    }, 250);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Backup & Restore</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>Manage system data backups</p>
        </div>
        <Button onClick={handleBackup} disabled={isBackingUp} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <HardDrive className="w-4 h-4" />
          {isBackingUp ? 'Backing up...' : 'Create Backup'}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: s.bg }}>
                <Icon className="w-5 h-5" style={{ color: s.color }} />
              </div>
              <p style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>{s.value}</p>
              <p style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Backup progress */}
      {isBackingUp && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
            </div>
            <div>
              <p style={{ fontWeight: 600, color: '#1e40af', fontSize: '14px' }}>Creating backup...</p>
              <p style={{ fontSize: '12px', color: '#3b82f6' }}>{backupProgress}% complete</p>
            </div>
          </div>
          <Progress value={backupProgress} className="h-2" />
        </div>
      )}

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { title: 'Scheduled Backup', desc: 'Runs daily at 8:00 AM automatically', icon: Clock, color: '#1d4ed8', status: 'Enabled', statusColor: 'text-emerald-600' },
          { title: 'Cloud Sync', desc: 'Sync to Google Drive every Sunday', icon: Cloud, color: '#7c3aed', status: 'Active', statusColor: 'text-emerald-600' },
          { title: 'Email Notification', desc: 'Alert on backup failure', icon: Shield, color: '#d97706', status: 'Enabled', statusColor: 'text-emerald-600' },
        ].map((a, i) => {
          const Icon = a.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="flex items-center justify-between mb-2">
                <div className="w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center">
                  <Icon className="w-5 h-5" style={{ color: a.color }} />
                </div>
                <span className={`${a.statusColor} text-xs font-medium`}>{a.status}</span>
              </div>
              <p style={{ fontWeight: 600, color: '#1e293b', fontSize: '13.5px' }}>{a.title}</p>
              <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '2px' }}>{a.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Backup history */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Backup History</h3>
          <span style={{ fontSize: '12.5px', color: '#94a3b8' }}>{backupHistory.length} records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['Backup File', 'Type', 'Size', 'Date & Time', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {backupHistory.map(b => (
                <tr key={b.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
                        <Database className="w-4 h-4 text-slate-500" />
                      </div>
                      <span style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b', fontFamily: 'monospace' }}>{b.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full ${b.type === 'Manual' ? 'bg-purple-50 text-purple-600 border border-purple-200' : 'bg-blue-50 text-blue-600 border border-blue-200'}`}
                      style={{ fontSize: '11.5px', fontWeight: 500 }}>
                      {b.type}
                    </span>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{b.size}</td>
                  <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b' }}>{b.date}</td>
                  <td className="px-4 py-3">
                    {b.status === 'Success' ? (
                      <span className="flex items-center gap-1 text-emerald-600" style={{ fontSize: '12.5px', fontWeight: 500 }}>
                        <CheckCircle className="w-3.5 h-3.5" /> Success
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-red-600" style={{ fontSize: '12.5px', fontWeight: 500 }}>
                        <AlertTriangle className="w-3.5 h-3.5" /> Failed
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors"
                        style={{ fontSize: '12px' }}>
                        <Download className="w-3.5 h-3.5" /> Download
                      </button>
                      {b.status === 'Success' && (
                        <button onClick={() => { setSelectedBackup(b); setShowRestore(true); }}
                          className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-amber-50 text-slate-500 hover:text-amber-600 transition-colors"
                          style={{ fontSize: '12px' }}>
                          <Upload className="w-3.5 h-3.5" /> Restore
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Restore Modal */}
      <Dialog open={showRestore} onOpenChange={setShowRestore}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Restore from Backup</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p style={{ fontWeight: 600, color: '#92400e', fontSize: '14px' }}>Warning</p>
                  <p style={{ fontSize: '13px', color: '#b45309', marginTop: '2px' }}>
                    Restoring will overwrite all current data. This action cannot be undone.
                  </p>
                </div>
              </div>
            </div>
            {selectedBackup && (
              <div className="p-3 bg-slate-50 rounded-xl">
                <p style={{ fontSize: '12.5px', color: '#64748b', marginBottom: '4px' }}>Restore from:</p>
                <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b', fontFamily: 'monospace' }}>{selectedBackup.name}</p>
                <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '2px' }}>{selectedBackup.date} • {selectedBackup.size}</p>
              </div>
            )}
            {isRestoring && (
              <div>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '12.5px', color: '#64748b' }}>Restoring data...</span>
                  <span style={{ fontSize: '12.5px', fontWeight: 600 }}>{restoreProgress}%</span>
                </div>
                <Progress value={restoreProgress} className="h-2" />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRestore(false)} disabled={isRestoring}>Cancel</Button>
            <Button variant="destructive" onClick={handleRestore} disabled={isRestoring}>
              {isRestoring ? 'Restoring...' : 'Confirm Restore'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
