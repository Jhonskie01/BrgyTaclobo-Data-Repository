import React from 'react';
import { X, LayoutDashboard, Users, Home, FileText, Award, AlertTriangle, Briefcase, BarChart3, Bell, User, LogOut, Shield } from 'lucide-react';

interface StaffSidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

export function StaffSidebar({ currentView, onNavigate, isOpen, onClose, onLogout }: StaffSidebarProps) {
  const menuItems = [
    { id: 'staff-dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'residents', label: 'Residents', icon: Users },
    { id: 'households', label: 'Households', icon: Home },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'certificates', label: 'Certificates', icon: Award },
    { id: 'incidents', label: 'Incidents / Blotter', icon: AlertTriangle },
    { id: 'projects', label: 'Projects', icon: Briefcase },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'staff-profile', label: 'Profile', icon: User },
  ];

  const handleNavigation = (viewId: string) => {
    onNavigate(viewId);
    onClose();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-50
          w-72 bg-white border-r border-gray-200
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          flex flex-col
        `}
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E40AF] to-[#3B82F6] rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900 text-sm">Barangay Data</h2>
                <p className="text-xs text-gray-500">Repository System</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="mt-3 px-3 py-2 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-xs font-semibold text-[#1E40AF]">STAFF ACCESS</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          <div className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavigation(item.id)}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-xl
                    transition-all duration-200 text-left
                    ${isActive
                      ? 'bg-gradient-to-r from-[#1E40AF] to-[#3B82F6] text-white shadow-lg shadow-blue-500/30'
                      : 'text-gray-700 hover:bg-gray-100'
                    }
                  `}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <span className="font-medium text-sm">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>

        {/* Footer - Logout */}
        <div className="p-4 border-t border-gray-200">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all duration-200"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium text-sm">Logout</span>
          </button>
        </div>

        {/* Version Info */}
        <div className="px-6 pb-4">
          <div className="text-center">
            <p className="text-xs text-gray-400">Staff Portal v1.0.0</p>
            <p className="text-xs text-gray-400 mt-1">© 2026 Barangay System</p>
          </div>
        </div>
      </aside>
    </>
  );
}
