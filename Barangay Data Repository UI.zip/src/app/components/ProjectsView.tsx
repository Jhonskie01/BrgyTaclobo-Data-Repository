import React, { useState } from 'react';
import { Plus, Search, Eye, Edit, FolderOpen, Calendar, DollarSign, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';

type ProjStatus = 'Planned' | 'Ongoing' | 'Completed' | 'Suspended';

const statusColors: Record<ProjStatus, { badge: string; bar: string }> = {
  Planned: { badge: 'bg-slate-100 text-slate-600 border border-slate-200', bar: '#94a3b8' },
  Ongoing: { badge: 'bg-blue-50 text-blue-700 border border-blue-200', bar: '#3b82f6' },
  Completed: { badge: 'bg-emerald-50 text-emerald-700 border border-emerald-200', bar: '#10b981' },
  Suspended: { badge: 'bg-red-50 text-red-700 border border-red-200', bar: '#ef4444' },
};

const initialProjects = [
  { id: 1, name: 'Road Concreting Project Phase 1', category: 'Infrastructure', budget: 2500000, spent: 1875000, start: 'Jan 2026', end: 'Jun 2026', status: 'Ongoing' as ProjStatus, progress: 75, description: 'Concreting of road from Purok 1 to Purok 4, approximately 500 linear meters.' },
  { id: 2, name: 'Barangay Livelihood Program', category: 'Social Services', budget: 500000, spent: 500000, start: 'Mar 2026', end: 'Mar 2026', status: 'Completed' as ProjStatus, progress: 100, description: 'Skills training and seed capital distribution for 50 beneficiaries.' },
  { id: 3, name: 'Multi-Purpose Hall Renovation', category: 'Infrastructure', budget: 1200000, spent: 0, start: 'Jul 2026', end: 'Dec 2026', status: 'Planned' as ProjStatus, progress: 0, description: 'Renovation and expansion of the barangay multi-purpose hall.' },
  { id: 4, name: 'Street Lighting Installation', category: 'Utilities', budget: 350000, spent: 315000, start: 'Apr 2026', end: 'May 2026', status: 'Completed' as ProjStatus, progress: 100, description: 'LED street lights installation in Purok 5, 6, 7 and 8.' },
  { id: 5, name: 'Drainage Improvement Project', category: 'Infrastructure', budget: 800000, spent: 320000, start: 'May 2026', end: 'Sep 2026', status: 'Ongoing' as ProjStatus, progress: 40, description: 'Canal cleaning and improvement to prevent flooding.' },
  { id: 6, name: 'Day Care Center Construction', category: 'Education', budget: 1500000, spent: 0, start: 'Aug 2026', end: 'Dec 2026', status: 'Planned' as ProjStatus, progress: 0, description: 'Construction of new day care center at Purok 3.' },
  { id: 7, name: 'Health Outreach Program', category: 'Health', budget: 200000, spent: 150000, start: 'Feb 2026', end: 'Dec 2026', status: 'Ongoing' as ProjStatus, progress: 60, description: 'Monthly health consultations and free medicine distribution.' },
  { id: 8, name: 'Solid Waste Management', category: 'Environment', budget: 150000, spent: 0, start: 'Jun 2026', end: 'Dec 2026', status: 'Suspended' as ProjStatus, progress: 0, description: 'Segregation and composting program for all puroks.' },
];

type Project = typeof initialProjects[0];

const emptyForm = { name: '', category: 'Infrastructure', budget: '', start: '', end: '', description: '', status: 'Planned' as ProjStatus };

const categories = ['All', 'Infrastructure', 'Social Services', 'Utilities', 'Education', 'Health', 'Environment'];

export function ProjectsView() {
  const [projects, setProjects] = useState(initialProjects);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [selected, setSelected] = useState<Project | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  const filtered = projects.filter(p => {
    const q = search.toLowerCase();
    const match = !search || p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q);
    return match && (statusFilter === 'All' || p.status === statusFilter) && (categoryFilter === 'All' || p.category === categoryFilter);
  });

  const handleAdd = () => {
    const newP = { ...form, id: projects.length + 1, spent: 0, progress: 0, budget: Number(form.budget) || 0 };
    setProjects([newP, ...projects]);
    setShowAdd(false);
    setForm(emptyForm);
    toast.success('Project added successfully');
  };

  const totalBudget = projects.reduce((a, p) => a + p.budget, 0);
  const totalSpent = projects.reduce((a, p) => a + p.spent, 0);

  const summaryCards = [
    { label: 'Total Projects', value: projects.length, color: '#1d4ed8', bg: '#eff6ff' },
    { label: 'Ongoing', value: projects.filter(p => p.status === 'Ongoing').length, color: '#7c3aed', bg: '#f5f3ff' },
    { label: 'Completed', value: projects.filter(p => p.status === 'Completed').length, color: '#059669', bg: '#ecfdf5' },
    { label: 'Total Budget', value: `₱${(totalBudget / 1000000).toFixed(1)}M`, color: '#d97706', bg: '#fffbeb' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Projects</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>{filtered.length} projects</p>
        </div>
        <div className="flex gap-2">
          {(['cards', 'table'] as const).map(m => (
            <button key={m} onClick={() => setViewMode(m)}
              className={`px-3 py-1.5 rounded-xl border text-sm transition-colors ${viewMode === m ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}>
              {m === 'cards' ? 'Cards' : 'Table'}
            </button>
          ))}
          <Button onClick={() => setShowAdd(true)} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
            <Plus className="w-4 h-4" /> Add Project
          </Button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map((c, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all"
            style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <p style={{ fontSize: '24px', fontWeight: 700, color: c.color }}>{c.value}</p>
            <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '4px' }}>{c.label}</p>
          </div>
        ))}
      </div>

      {/* Budget overview */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex items-center justify-between mb-3">
          <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Budget Overview</h3>
          <span style={{ fontSize: '13px', color: '#64748b' }}>
            ₱{(totalSpent / 1000000).toFixed(2)}M of ₱{(totalBudget / 1000000).toFixed(2)}M utilized
          </span>
        </div>
        <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
          <div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-700 transition-all"
            style={{ width: `${Math.min((totalSpent / totalBudget) * 100, 100)}%` }} />
        </div>
        <div className="flex justify-between mt-1.5">
          <span style={{ fontSize: '11.5px', color: '#94a3b8' }}>Budget Utilized: {((totalSpent / totalBudget) * 100).toFixed(1)}%</span>
          <span style={{ fontSize: '11.5px', color: '#94a3b8' }}>Remaining: ₱{((totalBudget - totalSpent) / 1000000).toFixed(2)}M</span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search projects..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            {[['Status', statusFilter, setStatusFilter, ['All', 'Planned', 'Ongoing', 'Completed', 'Suspended']],
              ['Category', categoryFilter, setCategoryFilter, categories]
            ].map(([label, val, setter, opts]) => (
              <select key={label as string} value={val as string} onChange={e => (setter as any)(e.target.value)}
                className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {(opts as string[]).map(o => <option key={o}>{o === 'All' ? `${label}: All` : o}</option>)}
              </select>
            ))}
          </div>
        </div>
      </div>

      {/* Projects grid/table */}
      {viewMode === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(p => {
            const sc = statusColors[p.status];
            return (
              <div key={p.id} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition-all cursor-pointer"
                style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}
                onClick={() => { setSelected(p); setShowDetail(true); }}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-lg" style={{ fontSize: '11px', fontWeight: 600 }}>{p.category}</span>
                      <span className={`px-2 py-0.5 rounded-full ${sc.badge}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>{p.status}</span>
                    </div>
                    <h4 style={{ fontSize: '14px', fontWeight: 700, color: '#0f172a', lineHeight: 1.3 }}>{p.name}</h4>
                  </div>
                </div>
                <p style={{ fontSize: '12.5px', color: '#64748b', marginBottom: '12px' }} className="line-clamp-2">{p.description}</p>
                <div className="mb-3">
                  <div className="flex justify-between mb-1">
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Budget Progress</span>
                    <span style={{ fontSize: '12px', fontWeight: 600, color: '#1e293b' }}>{p.progress}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${p.progress}%`, background: sc.bar }} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                    <span style={{ fontSize: '12.5px', color: '#374151' }}>₱{(p.budget / 1000000).toFixed(2)}M</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>{p.start} – {p.end}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                  {['Project Name', 'Category', 'Budget', 'Progress', 'Timeline', 'Status', 'Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => {
                  const sc = statusColors[p.status];
                  return (
                    <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3">
                        <div>
                          <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{p.name}</p>
                          <span className="px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded" style={{ fontSize: '11px' }}>{p.category}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>₱{(p.budget / 1000000).toFixed(2)}M</td>
                      <td className="px-4 py-3 min-w-[120px]">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${p.progress}%`, background: sc.bar }} />
                          </div>
                          <span style={{ fontSize: '12px', fontWeight: 600, color: '#374151', whiteSpace: 'nowrap' }}>{p.progress}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b', whiteSpace: 'nowrap' }}>{p.start} – {p.end}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full ${sc.badge}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>{p.status}</span>
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => { setSelected(p); setShowDetail(true); }}
                          className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Modal */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add New Project</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2 max-h-[65vh] overflow-y-auto pr-1">
            {[['Project Name', 'name'], ['Budget (₱)', 'budget', 'number']].map(([label, key, type = 'text']) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <input type={type} value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Start Date</label>
                <input type="month" value={form.start} onChange={e => setForm({ ...form, start: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>End Date</label>
                <input type="month" value={form.end} onChange={e => setForm({ ...form, end: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>
            {[['Category', 'category', categories.slice(1)], ['Status', 'status', ['Planned', 'Ongoing', 'Completed', 'Suspended']]].map(([label, key, opts]) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <select value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Description</label>
              <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                rows={3} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAdd}>Save Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Modal */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Project Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-xl">
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 bg-blue-200 text-blue-700 rounded-lg" style={{ fontSize: '11px', fontWeight: 600 }}>{selected.category}</span>
                  <span className={`px-2 py-0.5 rounded-full ${statusColors[selected.status].badge}`} style={{ fontSize: '11.5px' }}>{selected.status}</span>
                </div>
                <h3 style={{ fontWeight: 700, color: '#0f172a', fontSize: '15px' }}>{selected.name}</h3>
              </div>
              <p style={{ fontSize: '13.5px', color: '#374151' }}>{selected.description}</p>
              <div>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '13px', color: '#64748b' }}>Budget Progress ({selected.progress}%)</span>
                  <span style={{ fontSize: '13px', fontWeight: 600 }}>₱{(selected.spent / 1000000).toFixed(2)}M / ₱{(selected.budget / 1000000).toFixed(2)}M</span>
                </div>
                <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${selected.progress}%`, background: statusColors[selected.status].bar }} />
                </div>
              </div>
              {[['Timeline', `${selected.start} – ${selected.end}`], ['Budget Remaining', `₱${((selected.budget - selected.spent) / 1000000).toFixed(2)}M`]].map(([k, v]) => (
                <div key={k as string} className="flex justify-between py-1.5 border-b border-slate-50">
                  <span style={{ fontSize: '13px', color: '#64748b' }}>{k}</span>
                  <span style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b' }}>{v}</span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setShowDetail(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
