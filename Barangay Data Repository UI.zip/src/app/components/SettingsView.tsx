import React, { useState } from 'react';
import { Save, Bell, Lock, Globe, Database, Palette, MapPin, Phone, Mail, Building } from 'lucide-react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { toast } from 'sonner';

const tabs = ['Barangay Info', 'Notifications', 'Security', 'System'];

export function SettingsView() {
  const [activeTab, setActiveTab] = useState('Barangay Info');
  const [barangayInfo, setBarangayInfo] = useState({
    name: 'Barangay San Jose',
    municipality: 'Municipality of Sta. Rosa',
    province: 'Laguna',
    region: 'CALABARZON (Region IV-A)',
    captain: 'Jose Rizal Jr.',
    secretary: 'Ana Cruz',
    treasurer: 'Pedro Santos',
    phone: '(049) 123-4567',
    email: 'brgy.sanjose@example.gov.ph',
    address: 'Barangay Hall, San Jose St., Sta. Rosa, Laguna',
    zipCode: '4026',
  });

  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    smsAlerts: false,
    newResident: true,
    certRequest: true,
    incidentReport: true,
    backupComplete: true,
    weeklyReport: false,
  });

  const [security, setSecurity] = useState({
    twoFactor: false,
    sessionTimeout: '30',
    passwordExpiry: '90',
    loginAttempts: '5',
  });

  const [system, setSystem] = useState({
    language: 'Filipino',
    timezone: 'Asia/Manila (GMT+8)',
    dateFormat: 'MM/DD/YYYY',
    autoBackup: true,
    maintenanceMode: false,
    dataRetention: '5 years',
  });

  const handleSave = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Settings</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>System configuration and preferences</p>
        </div>
        <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <Save className="w-4 h-4" /> Save Changes
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit">
        {tabs.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg transition-all ${activeTab === tab ? 'bg-white shadow-sm' : 'hover:bg-white/50'}`}
            style={{ fontSize: '13.5px', fontWeight: activeTab === tab ? 600 : 400, color: activeTab === tab ? '#1e293b' : '#64748b' }}>
            {tab}
          </button>
        ))}
      </div>

      {/* Barangay Info */}
      {activeTab === 'Barangay Info' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Building className="w-4 h-4 text-blue-600" />
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Barangay Identity</h3>
            </div>
            <div className="space-y-4">
              {[
                ['Barangay Name', 'name'],
                ['Municipality', 'municipality'],
                ['Province', 'province'],
                ['Region', 'region'],
              ].map(([label, key]) => (
                <div key={key as string}>
                  <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                  <input value={(barangayInfo as any)[key as string]}
                    onChange={e => setBarangayInfo({ ...barangayInfo, [key as string]: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Phone className="w-4 h-4 text-blue-600" />
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Contact Information</h3>
            </div>
            <div className="space-y-4">
              {[['Barangay Captain', 'captain'], ['Secretary', 'secretary'], ['Treasurer', 'treasurer'], ['Phone', 'phone'], ['Email', 'email'], ['Address', 'address'], ['ZIP Code', 'zipCode']].map(([label, key]) => (
                <div key={key as string}>
                  <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                  <input value={(barangayInfo as any)[key as string]}
                    onChange={e => setBarangayInfo({ ...barangayInfo, [key as string]: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Notifications */}
      {activeTab === 'Notifications' && (
        <div className="bg-white rounded-2xl p-5 border border-slate-100 max-w-2xl" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center gap-2 mb-5">
            <Bell className="w-4 h-4 text-blue-600" />
            <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Notification Preferences</h3>
          </div>
          <div className="space-y-4">
            {[
              ['Email Alerts', 'emailAlerts', 'Receive system alerts via email'],
              ['SMS Alerts', 'smsAlerts', 'Receive important alerts via SMS'],
              ['New Resident Registration', 'newResident', 'Alert when new resident is registered'],
              ['Certificate Request', 'certRequest', 'Alert on new certificate requests'],
              ['Incident Report', 'incidentReport', 'Alert when new incident is filed'],
              ['Backup Complete', 'backupComplete', 'Alert when backup completes'],
              ['Weekly Report', 'weeklyReport', 'Receive weekly summary email'],
            ].map(([label, key, desc]) => (
              <div key={key as string} className="flex items-center justify-between py-3 border-b border-slate-50">
                <div>
                  <p style={{ fontSize: '13.5px', fontWeight: 500, color: '#1e293b' }}>{label}</p>
                  <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '1px' }}>{desc}</p>
                </div>
                <Switch
                  checked={(notifications as any)[key as string]}
                  onCheckedChange={v => setNotifications({ ...notifications, [key as string]: v })}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Security */}
      {activeTab === 'Security' && (
        <div className="bg-white rounded-2xl p-5 border border-slate-100 max-w-2xl" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center gap-2 mb-5">
            <Lock className="w-4 h-4 text-blue-600" />
            <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Security Settings</h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-slate-50">
              <div>
                <p style={{ fontSize: '13.5px', fontWeight: 500, color: '#1e293b' }}>Two-Factor Authentication</p>
                <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '1px' }}>Require 2FA for all user logins</p>
              </div>
              <Switch checked={security.twoFactor} onCheckedChange={v => setSecurity({ ...security, twoFactor: v })} />
            </div>
            {[
              ['Session Timeout (minutes)', 'sessionTimeout'],
              ['Password Expiry (days)', 'passwordExpiry'],
              ['Max Login Attempts', 'loginAttempts'],
            ].map(([label, key]) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <input type="number" value={(security as any)[key as string]}
                  onChange={e => setSecurity({ ...security, [key as string]: e.target.value })}
                  className="w-32 px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* System */}
      {activeTab === 'System' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <div className="flex items-center gap-2 mb-5">
              <Globe className="w-4 h-4 text-blue-600" />
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Regional Settings</h3>
            </div>
            <div className="space-y-4">
              {[
                ['Language', 'language', ['Filipino', 'English']],
                ['Timezone', 'timezone', ['Asia/Manila (GMT+8)']],
                ['Date Format', 'dateFormat', ['MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD']],
                ['Data Retention', 'dataRetention', ['1 year', '3 years', '5 years', '10 years', 'Permanent']],
              ].map(([label, key, opts]) => (
                <div key={key as string}>
                  <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                  <select value={(system as any)[key as string]}
                    onChange={e => setSystem({ ...system, [key as string]: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <div className="flex items-center gap-2 mb-5">
              <Database className="w-4 h-4 text-blue-600" />
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>System Options</h3>
            </div>
            <div className="space-y-4">
              {[
                ['Auto Backup', 'autoBackup', 'Daily automatic data backup'],
                ['Maintenance Mode', 'maintenanceMode', 'Disable access for non-admins'],
              ].map(([label, key, desc]) => (
                <div key={key as string} className="flex items-center justify-between py-3 border-b border-slate-50">
                  <div>
                    <p style={{ fontSize: '13.5px', fontWeight: 500, color: '#1e293b' }}>{label}</p>
                    <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '1px' }}>{desc}</p>
                  </div>
                  <Switch checked={(system as any)[key as string]}
                    onCheckedChange={v => setSystem({ ...system, [key as string]: v })} />
                </div>
              ))}
              <div className="p-3 bg-slate-50 rounded-xl mt-4">
                <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b', marginBottom: '8px' }}>System Information</p>
                {[['Version', 'v2.1.0'], ['Database', 'PostgreSQL 16.2'], ['Last Update', 'May 15, 2026'], ['Environment', 'Production']].map(([k, v]) => (
                  <div key={k as string} className="flex justify-between py-1">
                    <span style={{ fontSize: '12px', color: '#64748b' }}>{k}</span>
                    <span style={{ fontSize: '12px', fontWeight: 500, color: '#1e293b' }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
