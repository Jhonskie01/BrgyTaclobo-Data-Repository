import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, Shield, CheckCircle, Copy, Database, Users, FileText, Award, BarChart3, HardDrive } from 'lucide-react';
import { toast } from 'sonner';

interface LoginViewProps {
  onLogin: (role: 'admin' | 'staff') => void;
}

export function LoginView({ onLogin }: LoginViewProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  // Update date/time every second
  React.useEffect(() => {
    const timer = setInterval(() => setCurrentDateTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();

    if (!username || !password) {
      toast.error('Please enter both username and password');
      return;
    }

    setIsLoading(true);

    // Simulate login delay
    setTimeout(() => {
      if (username === 'admin' && password === 'admin123') {
        toast.success('Welcome back, Administrator!');
        onLogin('admin');
      } else if (username === 'staff' && password === 'staff123') {
        toast.success('Welcome back, Staff Member!');
        onLogin('staff');
      } else {
        toast.error('Invalid username or password');
        setIsLoading(false);
      }
    }, 1000);
  };

  const copyCredentials = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
    toast.success('Credentials copied to form');
  };

  const formatDateTime = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="min-h-screen flex overflow-hidden">
      {/* Left Side - Branding & Features */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-[#1E40AF] via-[#3B82F6] to-[#60A5FA]">
        {/* Decorative Background Elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>

        {/* Glassmorphism Overlay */}
        <div className="absolute inset-0 backdrop-blur-sm bg-white/5"></div>

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center px-12 xl:px-20 text-white w-full">
          {/* Logo Placeholder */}
          <div className="mb-8 flex items-center gap-4">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/30">
              <Shield className="w-12 h-12 text-white" />
            </div>
            <div>
              <div className="text-sm font-medium opacity-90">Republic of the Philippines</div>
              <div className="text-xs opacity-75">Local Government Unit</div>
            </div>
          </div>

          {/* Title */}
          <div className="mb-6">
            <h1 className="text-5xl font-bold mb-3 leading-tight">
              Barangay Data<br />Repository System
            </h1>
            <p className="text-lg text-white/90 max-w-lg leading-relaxed">
              Centralized Digital Management System for Residents, Households, Documents, Certificates, Projects, and Barangay Records.
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="space-y-3 mb-12">
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <Users className="w-4 h-4" />
              </div>
              <span className="font-medium">Resident Management</span>
            </div>
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <Database className="w-4 h-4" />
              </div>
              <span className="font-medium">Household Repository</span>
            </div>
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <Award className="w-4 h-4" />
              </div>
              <span className="font-medium">Certificate Processing</span>
            </div>
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <FileText className="w-4 h-4" />
              </div>
              <span className="font-medium">Incident Monitoring</span>
            </div>
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <BarChart3 className="w-4 h-4" />
              </div>
              <span className="font-medium">Reports & Analytics</span>
            </div>
            <div className="flex items-center gap-3 text-white/95">
              <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                <HardDrive className="w-4 h-4" />
              </div>
              <span className="font-medium">Secure Data Storage</span>
            </div>
          </div>

          {/* Security Badges */}
          <div className="flex flex-wrap gap-3">
            <div className="px-4 py-2 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-sm font-medium flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Encrypted Data
            </div>
            <div className="px-4 py-2 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-sm font-medium flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Secure Connection
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8 text-center">
            <div className="inline-flex w-16 h-16 bg-gradient-to-br from-[#1E40AF] to-[#3B82F6] rounded-2xl items-center justify-center mb-4">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Barangay Data Repository</h2>
          </div>

          {/* Date & Time Display */}
          <div className="mb-6 text-center">
            <div className="inline-block px-4 py-2 bg-white rounded-lg shadow-sm border border-gray-200">
              <p className="text-sm text-gray-600">{formatDateTime(currentDateTime)}</p>
            </div>
          </div>

          {/* Login Card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-200">
            {/* Card Header */}
            <div className="text-center mb-8">
              <div className="hidden lg:block mb-4">
                <div className="inline-flex w-16 h-16 bg-gradient-to-br from-[#1E40AF] to-[#3B82F6] rounded-2xl items-center justify-center">
                  <Shield className="w-10 h-10 text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Welcome Back</h3>
              <p className="text-gray-600">Sign in to access the system</p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-5">
              {/* Username Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3B82F6] focus:border-transparent transition-all outline-none bg-gray-50"
                  />
                </div>
              </div>

              {/* Password Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full pl-12 pr-12 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3B82F6] focus:border-transparent transition-all outline-none bg-gray-50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="flex items-center justify-between">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-[#3B82F6] focus:ring-[#3B82F6] cursor-pointer"
                  />
                  <span className="ml-2 text-sm text-gray-600">Remember me</span>
                </label>
                <button
                  type="button"
                  className="text-sm text-[#3B82F6] hover:text-[#1E40AF] transition-colors font-medium"
                >
                  Forgot Password?
                </button>
              </div>

              {/* Login Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-gradient-to-r from-[#1E40AF] to-[#3B82F6] text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Signing in...
                  </>
                ) : (
                  'Sign In'
                )}
              </button>
            </form>
          </div>

          {/* Demo Accounts */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-2xl p-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#3B82F6]" />
              Demo Accounts
            </h4>
            <div className="space-y-3">
              {/* Admin Account */}
              <div className="bg-white rounded-lg p-3 border border-blue-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-gray-700">Administrator</span>
                  <button
                    onClick={() => copyCredentials('admin', 'admin123')}
                    className="text-[#3B82F6] hover:text-[#1E40AF] transition-colors"
                    title="Copy credentials"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex gap-2">
                    <span className="text-gray-500 w-20">Username:</span>
                    <span className="font-mono text-gray-900">admin</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-gray-500 w-20">Password:</span>
                    <span className="font-mono text-gray-900">admin123</span>
                  </div>
                </div>
              </div>

              {/* Staff Account */}
              <div className="bg-white rounded-lg p-3 border border-blue-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-gray-700">Staff Member</span>
                  <button
                    onClick={() => copyCredentials('staff', 'staff123')}
                    className="text-[#3B82F6] hover:text-[#1E40AF] transition-colors"
                    title="Copy credentials"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex gap-2">
                    <span className="text-gray-500 w-20">Username:</span>
                    <span className="font-mono text-gray-900">staff</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-gray-500 w-20">Password:</span>
                    <span className="font-mono text-gray-900">staff123</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center space-y-2">
            <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
              <span className="px-3 py-1 bg-white rounded-full border border-gray-200">
                Version 1.0.0
              </span>
              <span className="px-3 py-1 bg-white rounded-full border border-gray-200">
                WCAG Compliant
              </span>
            </div>
            <p className="text-xs text-gray-500">
              © 2026 Barangay Data Repository System
            </p>
            <p className="text-xs text-gray-400">
              Powered by Modern Government Information System
            </p>
            <p className="text-xs text-gray-400 mt-2">
              Data Privacy Act Compliant • Republic Act 10173
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
