import React, { useState } from 'react';
import { Plus, Search, Edit, Trash2, Eye, Home, Users, Zap, Droplets, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { toast } from 'sonner';

const puroks = ['All', 'Purok 1', 'Purok 2', 'Purok 3', 'Purok 4', 'Purok 5', 'Purok 6', 'Purok 7', 'Purok 8'];
const housingTypes = ['All', 'Concrete', 'Semi-Concrete', 'Wood', 'Mixed Materials', 'Makeshift'];

const initialHouseholds = [
  { id: 1, number: 'HH-2026-001', head: 'Juan Dela Cruz', address: 'Blk 1 Lot 3, Purok 4', purok: 'Purok 4', members: 5, housing: 'Concrete', electricity: true, water: 'NAWASA', fourPs: false },
  { id: 2, number: 'HH-2026-002', head: 'Maria Clara Santos', address: 'Blk 2 Lot 7, Purok 2', purok: 'Purok 2', members: 3, housing: 'Semi-Concrete', electricity: true, water: 'Deep Well', fourPs: true },
  { id: 3, number: 'HH-2026-003', head: 'Roberto Reyes', address: 'Blk 3 Lot 1, Purok 6', purok: 'Purok 6', members: 7, housing: 'Wood', electricity: false, water: 'Deep Well', fourPs: true },
  { id: 4, number: 'HH-2026-004', head: 'Ana Gonzales', address: 'Blk 1 Lot 5, Purok 1', purok: 'Purok 1', members: 2, housing: 'Concrete', electricity: true, water: 'NAWASA', fourPs: false },
  { id: 5, number: 'HH-2026-005', head: 'Pedro Bautista', address: 'Blk 4 Lot 2, Purok 7', purok: 'Purok 7', members: 6, housing: 'Mixed Materials', electricity: true, water: 'Spring', fourPs: false },
  { id: 6, number: 'HH-2026-006', head: 'Liza Mendoza', address: 'Blk 2 Lot 9, Purok 3', purok: 'Purok 3', members: 4, housing: 'Concrete', electricity: true, water: 'NAWASA', fourPs: true },
  { id: 7, number: 'HH-2026-007', head: 'Carlos Garcia', address: 'Blk 5 Lot 11, Purok 5', purok: 'Purok 5', members: 3, housing: 'Semi-Concrete', electricity: false, water: 'Deep Well', fourPs: false },
  { id: 8, number: 'HH-2026-008', head: 'Rosa Flores', address: 'Blk 6 Lot 3, Purok 8', purok: 'Purok 8', members: 8, housing: 'Wood', electricity: true, water: 'NAWASA', fourPs: true },
];

type Household = typeof initialHouseholds[0];

const emptyForm = { number: '', head: '', address: '', purok: 'Purok 1', members: '', housing: 'Concrete', electricity: false, water: 'NAWASA', fourPs: false };

const summaryCards = [
  { label: 'Total Households', value: '1,247', icon: Home, color: '#1d4ed8', bg: '#eff6ff' },
  { label: 'Avg. Members', value: '4.8', icon: Users, color: '#0891b2', bg: '#ecfeff' },
  { label: 'With Electricity', value: '89%', icon: Zap, color: '#d97706', bg: '#fffbeb' },
  { label: '4Ps Beneficiary', value: '312', icon: Home, color: '#059669', bg: '#ecfdf5' },
];

export function HouseholdsView() {
  const [households, setHouseholds] = useState(initialHouseholds);
  const [search, setSearch] = useState('');
  const [purokFilter, setPurokFilter] = useState('All');
  const [housingFilter, setHousingFilter] = useState('All');
  const [fourPsFilter, setFourPsFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [showAdd, setShowAdd] = useState(false);
  const [showView, setShowView] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [selected, setSelected] = useState<Household | null>(null);
  const [form, setForm] = useState(emptyForm);
  const PER_PAGE = 7;

  const filtered = households.filter(h => {
    const q = search.toLowerCase();
    const match = !search || h.head.toLowerCase().includes(q) || h.number.toLowerCase().includes(q) || h.address.toLowerCase().includes(q);
    return match &&
      (purokFilter === 'All' || h.purok === purokFilter) &&
      (housingFilter === 'All' || h.housing === housingFilter) &&
      (fourPsFilter === 'All' || (fourPsFilter === 'Yes' ? h.fourPs : !h.fourPs));
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleAdd = () => {
    const newH = { ...form, id: households.length + 1, members: Number(form.members) || 1 } as Household;
    setHouseholds([newH, ...households]);
    setShowAdd(false);
    setForm(emptyForm);
    toast.success('Household added successfully');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Households</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>{filtered.length} households found</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setShowAdd(true); }} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <Plus className="w-4 h-4" /> Add Household
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map((c, i) => {
          const Icon = c.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: c.bg }}>
                <Icon className="w-5 h-5" style={{ color: c.color }} />
              </div>
              <p style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>{c.value}</p>
              <p style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{c.label}</p>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search by household number, head, address..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2 flex-wrap">
            {[
              ['Purok', purokFilter, setPurokFilter, puroks],
              ['Housing', housingFilter, setHousingFilter, housingTypes],
              ['4Ps', fourPsFilter, setFourPsFilter, ['All', 'Yes', 'No']],
            ].map(([label, val, setter, opts]) => (
              <select key={label as string} value={val as string}
                onChange={e => { (setter as any)(e.target.value); setPage(1); }}
                className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {(opts as string[]).map(o => <option key={o} value={o}>{o === 'All' ? `${label}: All` : o}</option>)}
              </select>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['HH Number', 'Head of Household', 'Address', 'Purok', 'Members', 'Housing Type', 'Electricity', 'Water Supply', '4Ps', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.map(h => (
                <tr key={h.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3"><span style={{ fontSize: '12.5px', fontWeight: 600, color: '#1d4ed8' }}>{h.number}</span></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <span style={{ fontSize: '10px', fontWeight: 700, color: '#1d4ed8' }}>{h.head.split(' ').map(n => n[0]).slice(0, 2).join('')}</span>
                      </div>
                      <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{h.head}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151', maxWidth: '180px' }}>
                    <span className="truncate block">{h.address}</span>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '13px', color: '#374151' }}>{h.purok}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{h.members}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-1 rounded-lg bg-slate-100 text-slate-600" style={{ fontSize: '11.5px' }}>{h.housing}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1 ${h.electricity ? 'text-amber-600' : 'text-slate-400'}`}>
                      <Zap className="w-3.5 h-3.5" />
                      <span style={{ fontSize: '12px' }}>{h.electricity ? 'Yes' : 'No'}</span>
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Droplets className="w-3.5 h-3.5 text-blue-400" />
                      <span style={{ fontSize: '12px', color: '#374151' }}>{h.water}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full ${h.fourPs ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-500'}`}
                      style={{ fontSize: '11.5px' }}>
                      {h.fourPs ? 'Yes' : 'No'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setSelected(h); setShowView(true); }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button onClick={() => { setSelected(h); setShowDelete(true); }}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
          <p style={{ fontSize: '12.5px', color: '#94a3b8' }}>
            Showing {Math.min((page - 1) * PER_PAGE + 1, filtered.length)}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}
          </p>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => (
              <button key={i + 1} onClick={() => setPage(i + 1)}
                className={`w-8 h-8 rounded-lg text-sm transition-colors ${page === i + 1 ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-600'}`}>
                {i + 1}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 text-slate-600">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add Modal */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Household</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {[['HH Number', 'number'], ['Head of Household', 'head'], ['Address', 'address'], ['Members Count', 'members', 'number']].map(([label, key, type = 'text']) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <input type={type} value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            ))}
            {[['Purok', 'purok', puroks.slice(1)], ['Housing Type', 'housing', housingTypes.slice(1)], ['Water Supply', 'water', ['NAWASA', 'Deep Well', 'Spring', 'River']]].map(([label, key, opts]) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <select value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div className="flex gap-4">
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.electricity} onChange={e => setForm({ ...form, electricity: e.target.checked })} className="rounded" /><span style={{ fontSize: '13px' }}>Has Electricity</span></label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.fourPs} onChange={e => setForm({ ...form, fourPs: e.target.checked })} className="rounded" /><span style={{ fontSize: '13px' }}>4Ps Beneficiary</span></label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAdd}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Modal */}
      <Dialog open={showView} onOpenChange={setShowView}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Household Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-2">
              <div className="p-3 bg-blue-50 rounded-xl">
                <p style={{ fontWeight: 700, color: '#1e293b', fontSize: '15px' }}>{selected.number}</p>
                <p style={{ color: '#64748b', fontSize: '13px' }}>{selected.head}</p>
              </div>
              {[['Address', selected.address], ['Purok', selected.purok], ['Members', selected.members], ['Housing Type', selected.housing], ['Electricity', selected.electricity ? 'Yes' : 'No'], ['Water Supply', selected.water], ['4Ps Beneficiary', selected.fourPs ? 'Yes' : 'No']].map(([k, v]) => (
                <div key={k as string} className="flex justify-between py-1.5 border-b border-slate-50">
                  <span style={{ fontSize: '13px', color: '#64748b' }}>{k}</span>
                  <span style={{ fontSize: '13px', fontWeight: 500, color: '#1e293b' }}>{String(v)}</span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setShowView(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={showDelete} onOpenChange={setShowDelete}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Household</DialogTitle></DialogHeader>
          <p style={{ fontSize: '14px', color: '#64748b' }}>Delete household <strong>{selected?.number}</strong>? This cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDelete(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { setHouseholds(households.filter(h => h.id !== selected?.id)); setShowDelete(false); toast.success('Household deleted'); }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
