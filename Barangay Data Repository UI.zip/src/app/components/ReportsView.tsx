import React, { useState } from 'react';
import { Download, FileText, BarChart3, Users, Home, Award, AlertTriangle, FolderOpen, TrendingUp, Calendar, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend } from 'recharts';
import { toast } from 'sonner';

const reportCards = [
  { title: 'Resident Report', desc: 'Complete list with demographics', icon: Users, color: '#1d4ed8', bg: '#eff6ff' },
  { title: 'Household Report', desc: 'Household data summary', icon: Home, color: '#0891b2', bg: '#ecfeff' },
  { title: 'Certificate Report', desc: 'All issued certificates', icon: Award, color: '#7c3aed', bg: '#f5f3ff' },
  { title: 'Incident Report', desc: 'Blotter and incident summary', icon: AlertTriangle, color: '#dc2626', bg: '#fef2f2' },
  { title: 'Project Report', desc: 'Budget and project status', icon: FolderOpen, color: '#d97706', bg: '#fffbeb' },
  { title: 'Annual Report', desc: 'Comprehensive annual summary', icon: TrendingUp, color: '#059669', bg: '#ecfdf5' },
];

const monthlyResidents = [
  { month: 'Jan', added: 15, removed: 3 },
  { month: 'Feb', added: 22, removed: 5 },
  { month: 'Mar', added: 18, removed: 2 },
  { month: 'Apr', added: 25, removed: 7 },
  { month: 'May', added: 31, removed: 4 },
  { month: 'Jun', added: 27, removed: 6 },
  { month: 'Jul', added: 35, removed: 8 },
  { month: 'Aug', added: 42, removed: 3 },
  { month: 'Sep', added: 29, removed: 5 },
  { month: 'Oct', added: 38, removed: 9 },
  { month: 'Nov', added: 24, removed: 4 },
  { month: 'Dec', added: 33, removed: 6 },
];

const certByType = [
  { name: 'Clearance', value: 142, color: '#3b82f6' },
  { name: 'Residency', value: 89, color: '#8b5cf6' },
  { name: 'Indigency', value: 67, color: '#06b6d4' },
  { name: 'Cedula', value: 45, color: '#f59e0b' },
  { name: 'Others', value: 46, color: '#10b981' },
];

const incidentsByMonth = [
  { month: 'Jan', incidents: 8 }, { month: 'Feb', incidents: 5 }, { month: 'Mar', incidents: 12 },
  { month: 'Apr', incidents: 7 }, { month: 'May', incidents: 9 }, { month: 'Jun', incidents: 11 },
  { month: 'Jul', incidents: 6 }, { month: 'Aug', incidents: 14 }, { month: 'Sep', incidents: 8 },
  { month: 'Oct', incidents: 10 }, { month: 'Nov', incidents: 7 }, { month: 'Dec', incidents: 9 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-lg">
        <p style={{ fontSize: '12px', fontWeight: 600, color: '#1e293b' }}>{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ fontSize: '12px', color: p.color }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  }
  return null;
};

const RADIAN = Math.PI / 180;
const renderLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
  if (percent < 0.05) return null;
  const r = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + r * Math.cos(-midAngle * RADIAN);
  const y = cy + r * Math.sin(-midAngle * RADIAN);
  return <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" style={{ fontSize: '11px', fontWeight: 700 }}>{`${(percent * 100).toFixed(0)}%`}</text>;
};

export function ReportsView() {
  const [yearFilter, setYearFilter] = useState('2026');
  const [reportType, setReportType] = useState('All');

  const handleExport = (format: string, report: string) => {
    toast.success(`Exporting ${report} as ${format}...`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>Reports & Analytics</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>Generate and export barangay reports</p>
        </div>
        <div className="flex gap-2">
          <select value={yearFilter} onChange={e => setYearFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-xl bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            {['2026', '2025', '2024', '2023'].map(y => <option key={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {/* Report cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {reportCards.map((r, i) => {
          const Icon = r.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition-all"
              style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: r.bg }}>
                  <Icon className="w-5 h-5" style={{ color: r.color }} />
                </div>
                <div className="flex gap-1">
                  <button onClick={() => handleExport('PDF', r.title)}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                    style={{ fontSize: '11px', fontWeight: 600 }}>
                    <Download className="w-3 h-3" /> PDF
                  </button>
                  <button onClick={() => handleExport('Excel', r.title)}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                    style={{ fontSize: '11px', fontWeight: 600 }}>
                    <Download className="w-3 h-3" /> Excel
                  </button>
                </div>
              </div>
              <h4 style={{ fontSize: '14px', fontWeight: 700, color: '#0f172a' }}>{r.title}</h4>
              <p style={{ fontSize: '12.5px', color: '#94a3b8', marginTop: '4px' }}>{r.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Charts section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Monthly residents */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Monthly Resident Movement</h3>
              <p style={{ fontSize: '12px', color: '#94a3b8' }}>New registrations vs removals</p>
            </div>
            <button onClick={() => handleExport('PDF', 'Monthly Residents')}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors">
              <Download className="w-4 h-4" />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyResidents} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="added" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Added" />
              <Bar dataKey="removed" fill="#f87171" radius={[4, 4, 0, 0]} name="Removed" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Certificates by type */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Certificates by Type</h3>
              <p style={{ fontSize: '12px', color: '#94a3b8' }}>Distribution of issued certificates</p>
            </div>
            <button onClick={() => handleExport('PDF', 'Certificates')}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
              <Download className="w-4 h-4" />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={certByType} cx="50%" cy="50%" innerRadius={55} outerRadius={85}
                labelLine={false} label={renderLabel} dataKey="value">
                {certByType.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-2 mt-2">
            {certByType.map((c, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ background: c.color }} />
                <span style={{ fontSize: '11px', color: '#64748b' }}>{c.name}: {c.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Incidents trend */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-100" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>Monthly Incident Trend</h3>
              <p style={{ fontSize: '12px', color: '#94a3b8' }}>Number of incidents filed per month</p>
            </div>
            <button onClick={() => handleExport('Excel', 'Incident Trend')}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 transition-colors">
              <Download className="w-4 h-4" />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={incidentsByMonth} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="incidents" stroke="#ef4444" strokeWidth={2.5} dot={{ fill: '#ef4444', r: 3 }} name="Incidents" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
