import React, { useState } from 'react';
import { Plus, Search, UserCog, Shield, Edit, Trash2, Eye, CheckCircle, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Switch } from './ui/switch';
import { toast } from 'sonner';

type Role = 'Administrator' | 'Barangay Captain' | 'Secretary' | 'Treasurer' | 'Kagawad' | 'Staff' | 'SK Officer';

const roleColors: Record<Role, string> = {
  'Administrator': 'bg-purple-100 text-purple-700 border border-purple-200',
  'Barangay Captain': 'bg-blue-100 text-blue-700 border border-blue-200',
  'Secretary': 'bg-indigo-100 text-indigo-700 border border-indigo-200',
  'Treasurer': 'bg-emerald-100 text-emerald-700 border border-emerald-200',
  'Kagawad': 'bg-amber-100 text-amber-700 border border-amber-200',
  'Staff': 'bg-slate-100 text-slate-600 border border-slate-200',
  'SK Officer': 'bg-pink-100 text-pink-700 border border-pink-200',
};

const initialUsers = [
  { id: 1, name: 'Maria Santos', email: 'maria.admin@brgy-sanjose.gov.ph', role: 'Administrator' as Role, status: true, lastLogin: 'May 29, 2026 08:42 AM', joined: 'Jan 2024' },
  { id: 2, name: 'Jose Rizal Jr.', email: 'jose.captain@brgy-sanjose.gov.ph', role: 'Barangay Captain' as Role, status: true, lastLogin: 'May 29, 2026 07:30 AM', joined: 'Jan 2022' },
  { id: 3, name: 'Ana Cruz', email: 'ana.secretary@brgy-sanjose.gov.ph', role: 'Secretary' as Role, status: true, lastLogin: 'May 28, 2026 04:15 PM', joined: 'Mar 2023' },
  { id: 4, name: 'Pedro Santos', email: 'pedro.treasurer@brgy-sanjose.gov.ph', role: 'Treasurer' as Role, status: true, lastLogin: 'May 27, 2026 10:00 AM', joined: 'Jun 2022' },
  { id: 5, name: 'Carlos Reyes', email: 'carlos.kagawad@brgy-sanjose.gov.ph', role: 'Kagawad' as Role, status: true, lastLogin: 'May 26, 2026 02:30 PM', joined: 'Jan 2022' },
  { id: 6, name: 'Elena Garcia', email: 'elena.kagawad@brgy-sanjose.gov.ph', role: 'Kagawad' as Role, status: true, lastLogin: 'May 25, 2026 11:00 AM', joined: 'Jan 2022' },
  { id: 7, name: 'Roberto Flores', email: 'roberto.staff@brgy-sanjose.gov.ph', role: 'Staff' as Role, status: false, lastLogin: 'May 20, 2026 09:00 AM', joined: 'Sep 2024' },
  { id: 8, name: 'Rosa Bautista', email: 'rosa.sk@brgy-sanjose.gov.ph', role: 'SK Officer' as Role, status: true, lastLogin: 'May 24, 2026 03:45 PM', joined: 'Nov 2023' },
];

type User = typeof initialUsers[0];

const emptyForm = { name: '', email: '', role: 'Staff' as Role, password: '' };

const roles: Role[] = ['Administrator', 'Barangay Captain', 'Secretary', 'Treasurer', 'Kagawad', 'Staff', 'SK Officer'];

export function UserManagementView() {
  const [users, setUsers] = useState(initialUsers);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [showAdd, setShowAdd] = useState(false);
  const [showView, setShowView] = useState(false);
  const [selected, setSelected] = useState<User | null>(null);
  const [form, setForm] = useState(emptyForm);

  const filtered = users.filter(u => {
    const q = search.toLowerCase();
    const match = !search || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
    return match && (roleFilter === 'All' || u.role === roleFilter);
  });

  const toggleStatus = (id: number) => {
    setUsers(users.map(u => u.id === id ? { ...u, status: !u.status } : u));
    const u = users.find(u => u.id === id);
    toast.success(`${u?.name} ${u?.status ? 'deactivated' : 'activated'}`);
  };

  const handleAdd = () => {
    const newU = { ...form, id: users.length + 1, status: true, lastLogin: 'Never', joined: 'May 2026' };
    setUsers([...users, newU]);
    setShowAdd(false);
    setForm(emptyForm);
    toast.success('User account created');
  };

  const handleDelete = (id: number) => {
    const u = users.find(u => u.id === id);
    setUsers(users.filter(u => u.id !== id));
    toast.success(`${u?.name}'s account deleted`);
  };

  const stats = [
    { label: 'Total Users', value: users.length, color: '#1d4ed8', bg: '#eff6ff' },
    { label: 'Active', value: users.filter(u => u.status).length, color: '#059669', bg: '#ecfdf5' },
    { label: 'Inactive', value: users.filter(u => !u.status).length, color: '#dc2626', bg: '#fef2f2' },
    { label: 'Roles', value: new Set(users.map(u => u.role)).size, color: '#7c3aed', bg: '#f5f3ff' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#0f172a' }}>User Management</h1>
          <p style={{ fontSize: '13.5px', color: '#64748b', marginTop: '2px' }}>Manage staff accounts and permissions</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-blue-600 hover:bg-blue-700 gap-2 rounded-xl">
          <Plus className="w-4 h-4" /> Add User
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all"
            style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
            <p style={{ fontSize: '26px', fontWeight: 700, color: s.color }}>{s.value}</p>
            <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search by name or email..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="All">Role: All</option>
            {roles.map(r => <option key={r}>{r}</option>)}
          </select>
        </div>
      </div>

      {/* User table */}
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{ boxShadow: '0 1px 8px rgba(0,0,0,0.05)' }}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                {['User', 'Role', 'Status', 'Last Login', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: u.status ? '#eff6ff' : '#f1f5f9' }}>
                        <span style={{ fontSize: '12px', fontWeight: 700, color: u.status ? '#1d4ed8' : '#94a3b8' }}>
                          {u.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                        </span>
                      </div>
                      <div>
                        <p style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{u.name}</p>
                        <p style={{ fontSize: '11.5px', color: '#94a3b8' }}>{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full w-fit ${roleColors[u.role]}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>
                      <Shield className="w-3 h-3" />
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Switch checked={u.status} onCheckedChange={() => toggleStatus(u.id)} />
                      <span style={{ fontSize: '12px', color: u.status ? '#059669' : '#dc2626', fontWeight: 500 }}>
                        {u.status ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b' }}>{u.lastLogin}</td>
                  <td className="px-4 py-3" style={{ fontSize: '12.5px', color: '#64748b' }}>{u.joined}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setSelected(u); setShowView(true); }}
                        className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-amber-50 text-slate-400 hover:text-amber-600 transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(u.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add User Account</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            {[['Full Name', 'name'], ['Email Address', 'email', 'email'], ['Password', 'password', 'password']].map(([label, key, type = 'text']) => (
              <div key={key as string}>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>{label}</label>
                <input type={type} value={(form as any)[key as string]} onChange={e => setForm({ ...form, [key as string]: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            ))}
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Role</label>
              <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value as Role })}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {roles.map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAdd}>Create Account</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Modal */}
      <Dialog open={showView} onOpenChange={setShowView}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>User Details</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl">
                <div className="w-14 h-14 rounded-2xl bg-blue-200 flex items-center justify-center">
                  <span style={{ fontSize: '18px', fontWeight: 700, color: '#1d4ed8' }}>
                    {selected.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                  </span>
                </div>
                <div>
                  <p style={{ fontWeight: 700, color: '#1e293b', fontSize: '15px' }}>{selected.name}</p>
                  <span className={`px-2 py-0.5 rounded-full ${roleColors[selected.role]}`} style={{ fontSize: '11.5px', fontWeight: 500 }}>{selected.role}</span>
                </div>
              </div>
              {[['Email', selected.email], ['Status', selected.status ? 'Active' : 'Inactive'], ['Last Login', selected.lastLogin], ['Member Since', selected.joined]].map(([k, v]) => (
                <div key={k as string} className="flex justify-between py-1.5 border-b border-slate-50">
                  <span style={{ fontSize: '13px', color: '#64748b' }}>{k}</span>
                  <span style={{ fontSize: '13px', fontWeight: 500, color: k === 'Status' ? (selected.status ? '#059669' : '#dc2626') : '#1e293b' }}>{String(v)}</span>
                </div>
              ))}
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setShowView(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
