import React from "react";
import {
  Users,
  Home,
  Award,
  FileText,
  AlertTriangle,
  Clock,
  FolderOpen,
  UserCog,
  TrendingUp,
  TrendingDown,
  Activity,
  Eye,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts";

const statsCards = [
  {
    title: "Total Residents",
    value: "4,821",
    change: "+12",
    up: true,
    icon: Users,
    color: "#1d4ed8",
    bg: "#eff6ff",
  },
  {
    title: "Total Households",
    value: "1,247",
    change: "+5",
    up: true,
    icon: Home,
    color: "#0891b2",
    bg: "#ecfeff",
  },
  {
    title: "Certificates Issued",
    value: "389",
    change: "+28",
    up: true,
    icon: Award,
    color: "#7c3aed",
    bg: "#f5f3ff",
  },
  {
    title: "Uploaded Files",
    value: "1,054",
    change: "+47",
    up: true,
    icon: FileText,
    color: "#059669",
    bg: "#ecfdf5",
  },
  {
    title: "Active Incidents",
    value: "23",
    change: "-3",
    up: false,
    icon: AlertTriangle,
    color: "#dc2626",
    bg: "#fef2f2",
  },
  {
    title: "Pending Requests",
    value: "57",
    change: "+9",
    up: false,
    icon: Clock,
    color: "#d97706",
    bg: "#fffbeb",
  },
  {
    title: "Projects",
    value: "14",
    change: "+2",
    up: true,
    icon: FolderOpen,
    color: "#2563eb",
    bg: "#eff6ff",
  },
  {
    title: "Staff Accounts",
    value: "18",
    change: "0",
    up: true,
    icon: UserCog,
    color: "#475569",
    bg: "#f8fafc",
  },
];

const ageData = [
  { name: "Children (0-12)", value: 892, color: "#3b82f6" },
  { name: "Youth (13-24)", value: 1104, color: "#8b5cf6" },
  { name: "Adults (25-59)", value: 2187, color: "#06b6d4" },
  { name: "Senior (60+)", value: 638, color: "#f59e0b" },
];

const purokData = [
  { name: "Purok 1", residents: 487 },
  { name: "Purok 2", residents: 612 },
  { name: "Purok 3", residents: 534 },
  { name: "Purok 4", residents: 721 },
  { name: "Purok 5", residents: 398 },
  { name: "Purok 6", residents: 453 },
  { name: "Purok 7", residents: 616 },
  { name: "Purok 8", residents: 1000 },
];

const householdData = [
  { name: "Owned", value: 876, color: "#1d4ed8" },
  { name: "Rented", value: 248, color: "#06b6d4" },
  { name: "Shared", value: 123, color: "#8b5cf6" },
];

const monthlyData = [
  {
    month: "Jan",
    certificates: 28,
    incidents: 12,
    residents: 15,
  },
  {
    month: "Feb",
    certificates: 35,
    incidents: 8,
    residents: 22,
  },
  {
    month: "Mar",
    certificates: 42,
    incidents: 15,
    residents: 18,
  },
  {
    month: "Apr",
    certificates: 38,
    incidents: 11,
    residents: 25,
  },
  {
    month: "May",
    certificates: 55,
    incidents: 9,
    residents: 31,
  },
  {
    month: "Jun",
    certificates: 48,
    incidents: 14,
    residents: 27,
  },
  {
    month: "Jul",
    certificates: 62,
    incidents: 7,
    residents: 35,
  },
  {
    month: "Aug",
    certificates: 71,
    incidents: 18,
    residents: 42,
  },
  {
    month: "Sep",
    certificates: 58,
    incidents: 13,
    residents: 29,
  },
  {
    month: "Oct",
    certificates: 65,
    incidents: 10,
    residents: 38,
  },
  {
    month: "Nov",
    certificates: 43,
    incidents: 16,
    residents: 24,
  },
  {
    month: "Dec",
    certificates: 52,
    incidents: 11,
    residents: 33,
  },
];

const incidentStatusData = [
  { name: "Pending", value: 12, color: "#f59e0b" },
  { name: "Investigating", value: 8, color: "#3b82f6" },
  { name: "Resolved", value: 31, color: "#10b981" },
  { name: "Closed", value: 24, color: "#6b7280" },
];

const recentResidents = [
  {
    name: "Juan Dela Cruz",
    purok: "Purok 4",
    age: 34,
    date: "May 28, 2026",
  },
  {
    name: "Maria Clara Santos",
    purok: "Purok 2",
    age: 28,
    date: "May 27, 2026",
  },
  {
    name: "Roberto Reyes",
    purok: "Purok 6",
    age: 52,
    date: "May 26, 2026",
  },
  {
    name: "Ana Gonzales",
    purok: "Purok 1",
    age: 19,
    date: "May 25, 2026",
  },
  {
    name: "Pedro Bautista",
    purok: "Purok 7",
    age: 41,
    date: "May 24, 2026",
  },
];

const recentActivity = [
  {
    type: "cert",
    text: "Barangay Clearance issued to Liza Mendoza",
    time: "10 min ago",
    icon: Award,
    color: "#7c3aed",
  },
  {
    type: "resident",
    text: "New resident Juan Dela Cruz registered",
    time: "35 min ago",
    icon: Users,
    color: "#1d4ed8",
  },
  {
    type: "incident",
    text: "Blotter #2026-091 status updated to Resolved",
    time: "1 hr ago",
    icon: AlertTriangle,
    color: "#dc2626",
  },
  {
    type: "cert",
    text: "Certificate of Indigency issued to Rosa Flores",
    time: "2 hrs ago",
    icon: Award,
    color: "#7c3aed",
  },
  {
    type: "household",
    text: "Household #1248 added by admin",
    time: "3 hrs ago",
    icon: Home,
    color: "#0891b2",
  },
  {
    type: "file",
    text: "Document batch uploaded: 12 files",
    time: "4 hrs ago",
    icon: FileText,
    color: "#059669",
  },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-lg">
        <p
          style={{
            fontSize: "12px",
            fontWeight: 600,
            color: "#1e293b",
          }}
        >
          {label}
        </p>
        {payload.map((p: any, i: number) => (
          <p
            key={i}
            style={{ fontSize: "12px", color: p.color }}
          >
            {p.name}: <strong>{p.value}</strong>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const RADIAN = Math.PI / 180;
const renderCustomLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
}: any) => {
  if (percent < 0.06) return null;
  const r = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + r * Math.cos(-midAngle * RADIAN);
  const y = cy + r * Math.sin(-midAngle * RADIAN);
  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor="middle"
      dominantBaseline="central"
      style={{ fontSize: "11px", fontWeight: 700 }}
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

export function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            style={{
              fontSize: "22px",
              fontWeight: 700,
              color: "#0f172a",
            }}
          >
            Dashboard Overview
          </h1>
          <p
            style={{
              fontSize: "13.5px",
              color: "#64748b",
              marginTop: "2px",
            }}
          >
            Barangay Taclobo — Real-time data summary
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span
              style={{
                fontSize: "12px",
                color: "#15803d",
                fontWeight: 500,
              }}
            >
              System Online
            </span>
          </div>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statsCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              className="bg-white rounded-2xl p-4 border border-slate-100 hover:shadow-md transition-all duration-200"
              style={{
                boxShadow: "0 1px 8px rgba(0,0,0,0.05)",
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: card.bg }}
                >
                  <Icon
                    className="w-5 h-5"
                    style={{ color: card.color }}
                  />
                </div>
                <span
                  className={`flex items-center gap-0.5 text-xs font-medium ${card.up ? "text-emerald-600" : "text-red-500"}`}
                >
                  {card.up ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {card.change}
                </span>
              </div>
              <p
                style={{
                  fontSize: "24px",
                  fontWeight: 700,
                  color: "#0f172a",
                  lineHeight: 1,
                }}
              >
                {card.value}
              </p>
              <p
                style={{
                  fontSize: "12px",
                  color: "#64748b",
                  marginTop: "4px",
                }}
              >
                {card.title}
              </p>
            </div>
          );
        })}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Age distribution donut */}
        <div
          className="bg-white rounded-2xl p-5 border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <h3
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#0f172a",
              marginBottom: "4px",
            }}
          >
            Age Distribution
          </h3>
          <p
            style={{
              fontSize: "12px",
              color: "#94a3b8",
              marginBottom: "12px",
            }}
          >
            Residents by age group
          </p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={ageData}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={85}
                labelLine={false}
                label={renderCustomLabel}
                dataKey="value"
              >
                {ageData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v: any, n: string) => [
                  v.toLocaleString(),
                  n,
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-1 mt-2">
            {ageData.map((d, i) => (
              <div
                key={i}
                className="flex items-center gap-1.5"
              >
                <div
                  className="w-2.5 h-2.5 rounded-sm flex-shrink-0"
                  style={{ background: d.color }}
                />
                <span
                  style={{ fontSize: "11px", color: "#64748b" }}
                >
                  {d.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Residents per Purok */}
        <div
          className="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <h3
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#0f172a",
              marginBottom: "4px",
            }}
          >
            Residents per Purok
          </h3>
          <p
            style={{
              fontSize: "12px",
              color: "#94a3b8",
              marginBottom: "12px",
            }}
          >
            Population distribution across puroks
          </p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart
              data={purokData}
              margin={{
                top: 0,
                right: 0,
                left: -20,
                bottom: 0,
              }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#f1f5f9"
              />
              <XAxis
                dataKey="name"
                tick={{ fontSize: 11, fill: "#94a3b8" }}
              />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="residents"
                fill="#3b82f6"
                radius={[6, 6, 0, 0]}
                name="Residents"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly trends */}
        <div
          className="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <h3
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#0f172a",
              marginBottom: "4px",
            }}
          >
            Monthly Reports
          </h3>
          <p
            style={{
              fontSize: "12px",
              color: "#94a3b8",
              marginBottom: "12px",
            }}
          >
            Certificates, incidents & registrations
          </p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart
              data={monthlyData}
              margin={{
                top: 0,
                right: 0,
                left: -20,
                bottom: 0,
              }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#f1f5f9"
              />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 11, fill: "#94a3b8" }}
              />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: "12px" }}
              />
              <Line
                type="monotone"
                dataKey="certificates"
                stroke="#7c3aed"
                strokeWidth={2.5}
                dot={false}
                name="Certificates"
              />
              <Line
                type="monotone"
                dataKey="incidents"
                stroke="#ef4444"
                strokeWidth={2.5}
                dot={false}
                name="Incidents"
              />
              <Line
                type="monotone"
                dataKey="residents"
                stroke="#10b981"
                strokeWidth={2.5}
                dot={false}
                name="New Residents"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Incident status */}
        <div
          className="bg-white rounded-2xl p-5 border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <h3
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#0f172a",
              marginBottom: "4px",
            }}
          >
            Incident Status
          </h3>
          <p
            style={{
              fontSize: "12px",
              color: "#94a3b8",
              marginBottom: "8px",
            }}
          >
            Current blotter analytics
          </p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie
                data={incidentStatusData}
                cx="50%"
                cy="50%"
                outerRadius={70}
                labelLine={false}
                label={renderCustomLabel}
                dataKey="value"
              >
                {incidentStatusData.map((e, i) => (
                  <Cell key={i} fill={e.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v: any, n: string) => [v, n]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-3">
            {incidentStatusData.map((d, i) => (
              <div
                key={i}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-2.5 h-2.5 rounded-sm"
                    style={{ background: d.color }}
                  />
                  <span
                    style={{
                      fontSize: "12px",
                      color: "#64748b",
                    }}
                  >
                    {d.name}
                  </span>
                </div>
                <span
                  style={{
                    fontSize: "12px",
                    fontWeight: 600,
                    color: "#1e293b",
                  }}
                >
                  {d.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent residents */}
        <div
          className="bg-white rounded-2xl border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <div className="flex items-center justify-between p-5 border-b border-slate-100">
            <h3
              style={{
                fontSize: "14px",
                fontWeight: 600,
                color: "#0f172a",
              }}
            >
              Recent Residents
            </h3>
            <button
              className="flex items-center gap-1 text-blue-600 hover:text-blue-700 transition-colors"
              style={{ fontSize: "12px" }}
            >
              <Eye className="w-3.5 h-3.5" /> View all
            </button>
          </div>
          <div className="divide-y divide-slate-50">
            {recentResidents.map((r, i) => (
              <div
                key={i}
                className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50 transition-colors"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
                  <span
                    style={{
                      fontSize: "12px",
                      fontWeight: 700,
                      color: "#1d4ed8",
                    }}
                  >
                    {r.name
                      .split(" ")
                      .map((n) => n[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p
                    style={{
                      fontSize: "13px",
                      fontWeight: 600,
                      color: "#1e293b",
                    }}
                    className="truncate"
                  >
                    {r.name}
                  </p>
                  <p
                    style={{
                      fontSize: "11.5px",
                      color: "#94a3b8",
                    }}
                  >
                    {r.purok} • Age {r.age}
                  </p>
                </div>
                <span
                  style={{ fontSize: "11px", color: "#94a3b8" }}
                >
                  {r.date}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Activity log */}
        <div
          className="bg-white rounded-2xl border border-slate-100"
          style={{ boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}
        >
          <div className="flex items-center justify-between p-5 border-b border-slate-100">
            <h3
              style={{
                fontSize: "14px",
                fontWeight: 600,
                color: "#0f172a",
              }}
            >
              Activity Log
            </h3>
            <div className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-blue-500" />
              <span
                style={{ fontSize: "12px", color: "#64748b" }}
              >
                Live feed
              </span>
            </div>
          </div>
          <div className="divide-y divide-slate-50">
            {recentActivity.map((a, i) => {
              const Icon = a.icon;
              return (
                <div
                  key={i}
                  className="flex items-start gap-3 px-5 py-3 hover:bg-slate-50 transition-colors"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: `${a.color}15` }}
                  >
                    <Icon
                      className="w-4 h-4"
                      style={{ color: a.color }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      style={{
                        fontSize: "13px",
                        color: "#1e293b",
                      }}
                      className="truncate"
                    >
                      {a.text}
                    </p>
                    <p
                      style={{
                        fontSize: "11px",
                        color: "#94a3b8",
                        marginTop: "2px",
                      }}
                    >
                      {a.time}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}